/* tactics.js — 팀 전략 · 1/2/3픽 슬롯 전술 · AI 팀 전술
   - 개인 전술은 캐릭터가 아니라 라인업 픽 슬롯(0=1픽, 1=2픽, 2=3픽) 단위
   - AI 난이도는 파이터 개별 전투 AI가 아니라 팀이 짜는 전술 깊이만 바꿈
   - 로드 순서: draft.js 다음 (Draft 동명 함수 대체) */
(() => {
  const T = CONFIG.tactics, FD = id => CONFIG.fighters[id];
  const neutralTactic = () => { const o = {}; T.categories.forEach(c => { o[c.id] = [c.neutral, 4]; }); return o; };
  const neutralStrategy = () => { const o = {}; T.team.forEach(c => { o[c.id] = [c.neutral, 4]; }); return o; };
  const set = (o, id, v, lv) => { o[id] = [v, lv == null ? 4 : lv]; return o; };
  const isBack = f => !!(f.ai && f.ai.backline);
  const isFront = f => !!(f.ai && f.ai.front && !f.ai.backline);
  const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  const pick = a => a[Math.floor(Math.random() * a.length)];
  const SLOT_LANE = ['rush', 'flank', 'rear'];

  function presetSlot(slot, fid) {
    const t = neutralTactic();
    const f = fid ? FD(fid) : null;
    const s = slot | 0;
    if (s === 0) {
      set(t, 'lane', SLOT_LANE[0], 3); set(t, 'fight', 'coop', 3);
      if (f && f.role === 'assassin') { set(t, 'duty', 'hunt', 3); set(t, 'aim', 'back', 3); }
      else if (f && f.role === 'guardian') { set(t, 'duty', 'capture', 4); set(t, 'fight', 'support', 3); }
    } else if (s === 1) {
      set(t, 'lane', SLOT_LANE[1 % SLOT_LANE.length], 3); set(t, 'fight', 'coop', 3);
      if (f && f.role === 'assassin') { set(t, 'duty', 'hunt', 3); set(t, 'aim', 'weak', 3); }
      else if (f && isBack(f)) { set(t, 'pos', 'cover', 2); set(t, 'aim', 'carry', 3); }
    } else {
      set(t, 'lane', SLOT_LANE[2 % SLOT_LANE.length], 3); set(t, 'fight', 'support', 3);
      if (f && f.role === 'assassin') { set(t, 'duty', 'hunt', 3); set(t, 'aim', 'back', 3); }
      else if (f && isFront(f)) set(t, 'duty', 'guard', 3);
      else { set(t, 'aim', 'carry', 3); if (f && isBack(f)) set(t, 'pos', 'cover', 2); }
    }
    return t;
  }

  function presetTactic(fid) {
    const f = FD(fid);
    if (!f) return neutralTactic();
    if (f.role === 'assassin' || f.role === 'guardian' || isFront(f)) return presetSlot(0, fid);
    if (isBack(f)) return presetSlot(2, fid);
    return presetSlot(1, fid);
  }

  const PRESETS = {
    balanced:  { name: '균형 운영', desc: '기본 운영에 가벼운 팀플레이(집결·포커스·역할 이동)를 얹습니다.', set: { gather: ['two', 3], hurry: ['normal', 4], focus: ['weak', 3], chain: ['follow', 3], roleMove: ['split', 3], podCycle: ['cover', 3] } },
    lane:      { name: '진행 분담', desc: '1픽은 중앙 돌진, 2픽은 우회 후 기습, 3픽은 후방 지원으로 공격 진행을 나눕니다.', set: { formation: ['lanes', 5], stance: ['capture', 3], react: ['adapt', 3], retreat: ['careful', 2] } },
    aggro:     { name: '공세', desc: '킬을 앞세워 압박하고, 보스는 상대가 깎을 때 스틸합니다.', set: { stance: ['slay', 5], boss: ['steal', 4], lead: ['press', 4], retreat: ['brave', 3], ultT: ['burst', 4], react: ['adapt', 4], gather: ['two', 2], hurry: ['rash', 5], focus: ['weak', 5], chain: ['follow', 5], roleMove: ['split', 5] } },
    objective: { name: '오브젝트', desc: '중앙 보스와 회복팩을 중심으로 한 방에 판을 뒤집습니다.', set: { stance: ['objective', 5], boss: ['contest', 5], formation: ['group', 4], ultT: ['save', 4], trail: ['gamble', 4], react: ['smart', 4], gather: ['three', 5], hurry: ['patient', 4], focus: ['threat', 4], chain: ['follow', 4], roleMove: ['split', 4], podCycle: ['cover', 5] } },
    turtle:    { name: '수비 반격', desc: '목숨을 아끼다 앞서면 굳히고, 상대 보스 타이밍에 끼어듭니다.', set: { stance: ['defend', 5], boss: ['steal', 4], lead: ['turtle', 4], retreat: ['careful', 3], early: ['capture', 4], react: ['smart', 5], gather: ['three', 6], hurry: ['patient', 6], focus: ['back', 3], chain: ['follow', 3], roleMove: ['split', 3], podCycle: ['cover', 6] } }
  };
  function presetStrategy(name) {
    const s = neutralStrategy(), p = PRESETS[name];
    if (p) Object.entries(p.set).forEach(([k, v]) => { s[k] = v.slice(); });
    return s;
  }

  function lanesFor(ids, lv) {
    const fs = ids.map(FD), out = ids.map(() => null);
    const w = f => (f.role === 'assassin' ? 1 : (isFront(f) || f.role === 'guardian') ? 0 : isBack(f) ? 2 : 1);
    const order = ids.map((_, i) => i).sort((x, y) => w(fs[x]) - w(fs[y]));
    order.forEach((i, k) => { out[i] = [SLOT_LANE[Math.min(k, SLOT_LANE.length - 1)], lv]; });
    return out;
  }

  function aiTeam(level, ids, opp) {
    const S = neutralStrategy();
    let tac;
    const of = (opp || []).map(FD);
    const oppBack = of.filter(isBack).length;
    const oppFront = of.filter(f => isFront(f) || f.role === 'guardian').length;

    if (level === 'easy') {
      set(S, 'stance', 'slay', rnd(5, 7)); set(S, 'boss', 'yield'); set(S, 'react', 'fixed', 1);
      set(S, 'retreat', 'brave', rnd(5, 7)); set(S, 'formation', pick(['auto', 'group', 'split']), rnd(2, 5));      // easy: 팀 협동 항목은 모두 중립(각자 이동·각자 판단)
      tac = ids.map(() => {
        const t = neutralTactic();
        if (Math.random() < 0.45) set(t, 'duty', pick(['hunt', 'capture']), rnd(1, 3));
        if (Math.random() < 0.35) set(t, 'lane', pick(SLOT_LANE), rnd(2, 5));
        return t;
      });
    } else if (level === 'hard') {
      set(S, 'stance', 'balanced', 4); set(S, 'boss', 'steal', 3); set(S, 'react', 'smart', 5);
      set(S, 'lead', 'turtle', 4); set(S, 'trail', 'gamble', 4); set(S, 'ultT', 'save', 3);
      set(S, 'gather', 'two', 4); set(S, 'hurry', 'normal', 4); set(S, 'focus', 'weak', 4); set(S, 'chain', 'follow', 4); set(S, 'roleMove', 'split', 4); set(S, 'podCycle', 'cover', 3);      // hard: 대부분 켬
      tac = ids.map((id, i) => presetSlot(i, id));
      const ln = lanesFor(ids, 2);
      tac.forEach((t, i) => { if (!t.duty || t.duty[0] === 'none') t.lane = ln[i]; });
    } else if (level === 'master') {
      if (oppBack >= 2) set(S, 'stance', 'slay', 4);
      else if (oppFront >= 2) set(S, 'stance', 'capture', 5);
      else set(S, 'stance', 'balanced', 5);
      set(S, 'boss', 'steal', 5); set(S, 'react', 'smart', 7); set(S, 'lead', 'turtle', 5);
      set(S, 'trail', 'gamble', 5); set(S, 'retreat', 'careful', 3); set(S, 'ultT', 'save', 4);
      set(S, 'early', 'capture', 4); set(S, 'mid', 'objective', 4);
      /* master: 전부 켜고 정도도 높게. 포커스는 상대 구성을 보고 고름 */
      set(S, 'gather', 'three', 5); set(S, 'hurry', 'normal', 5); set(S, 'chain', 'follow', 6); set(S, 'roleMove', 'split', 6); set(S, 'podCycle', 'cover', 5);
      set(S, 'focus', oppBack >= 2 ? 'back' : oppFront >= 2 ? 'threat' : 'weak', 6);
      tac = ids.map((id, i) => presetSlot(i, id));
      const ln = lanesFor(ids, 3);
      tac.forEach((t, i) => { if (!t.duty || t.duty[0] === 'none') t.lane = ln[i]; });
    } else {
      set(S, 'stance', 'balanced', 4); set(S, 'react', 'adapt', 3);
      set(S, 'gather', 'two', 2); set(S, 'focus', 'weak', 2); set(S, 'chain', 'follow', 2);      // normal: 일부만 켬
      tac = ids.map((id, i) => presetSlot(i, id));
    }
    return { strategy: S, tactics: tac };
  }

  function neutralSlots() { return [0, 1, 2].map(i => presetSlot(i)); }

  Object.assign(Draft, {
    neutralTactic, neutralStrategy, presetTactic, presetSlot, presetStrategy,
    aiTactic: presetTactic, aiTeam, strategyPresets: PRESETS, neutralSlots
  });
})();
