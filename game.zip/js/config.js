/* ============================================================
   config.js — 수치·네이밍 설정. 파이터 본체(스탯/스킬)는 fighters.js 에 있습니다.
   - 스탯 단위: hp/mp 수치, aspd=초당 공격 횟수, spd=초당 이동 거리(유닛),
     atk/ap/def/res 수치, ten/pen/ls = 0~1 비율, range = 사거리(유닛, 근접 ≈ 6)
   - 피해 공식: 피해 = 원피해 × 100 / (100 + 방어(or 저항) × (1 - 관통력))
   ============================================================ */
const MAP_W = 225, MAP_H = 150, MAP_CX = 112.5, MAP_CY = 75;
const _rot = o => (o.t === 'c' ? { ...o, x: MAP_W - o.x, y: MAP_H - o.y } : { ...o, x: MAP_W - o.x - o.w, y: MAP_H - o.y - o.h });
const _rotPts = pts => pts.map(p => [MAP_W - p[0], MAP_H - p[1]]);
const _half = [
  { t: 'r', x: 28, y: 5,  w: 3,  h: 15, z: 12 }, { t: 'r', x: 5,  y: 28, w: 15, h: 3,  z: 12 },
  { t: 'r', x: 96, y: 4,  w: 3,  h: 10, z: 12 }, { t: 'r', x: 126, y: 4, w: 3,  h: 10, z: 12 },
  { t: 'r', x: 4,  y: 62, w: 14, h: 3,  z: 12 }, { t: 'r', x: 4,  y: 85, w: 14, h: 3,  z: 12 },
  { t: 'r', x: 40, y: 16, w: 14, h: 10, z: 30 }, { t: 'r', x: 92, y: 22, w: 12, h: 8,  z: 22 },
  { t: 'r', x: 66, y: 54, w: 10, h: 10, z: 26 }, { t: 'r', x: 36, y: 88, w: 12, h: 10, z: 28 },
  { t: 'r', x: 54, y: 96, w: 3,  h: 12, z: 10 }, { t: 'r', x: 6,  y: 100, w: 14, h: 12, z: 34 },
  ...[18, 63, 117, 162].map(a => ({ t: 'c', x: MAP_CX + 38 * Math.cos(a * Math.PI / 180), y: MAP_CY + 38 * Math.sin(a * Math.PI / 180), r: 3, z: 22 }))
];
const MAP_OBSTACLES = [..._half, ..._half.map(_rot)];
const _parkHalf = [ { x: 20, y: 44, w: 12, h: 10 }, { x: 74, y: 30, w: 14, h: 8 } ];
const MAP_PARKS = [..._parkHalf, ..._parkHalf.map(_rot)];
const _ringHalf = [[23, 125], [22, 100], [22, 75], [24, 40], [40, 24], [112.5, 20], [190, 20], [202, 21]];
const MAP_ROADS = [
  { w: 8, pts: _ringHalf }, { w: 8, pts: _rotPts(_ringHalf) },
  { w: 6, pts: [[22, 75], [86, 75]] }, { w: 6, pts: [[203, 75], [139, 75]] },
  { w: 6, pts: [[112.5, 20], [112.5, 49]] }, { w: 6, pts: [[112.5, 130], [112.5, 101]] },
  { w: 6, pts: [[23, 129], [88, 93]] }, { w: 6, pts: [[202, 21], [137, 57]] },
  { w: 6, pts: [[14, 14], [88, 57]] }, { w: 6, pts: [[211, 136], [137, 93]] }
];
const MAP_ZONES = [
  { id: 'pit', name: '중앙 보스 구덩이', x: MAP_CX, y: MAP_CY, r: 26, lane: 'core', hub: true, laneName: '중앙', laneDesc: '엄폐물 없는 중앙 구덩이 주변을 맡습니다. 보스전과 한타의 중심입니다.' },
  { id: 'nw', name: '북서 외곽', x: 42, y: 48, r: 30, lane: 'nw', laneName: '북서 외곽', laneDesc: '북서쪽 힐팩 지대를 맡아 소규모 교전과 회복 루트를 챙깁니다.' },
  { id: 'se', name: '남동 외곽', x: 183, y: 102, r: 30, lane: 'se', laneName: '남동 외곽', laneDesc: '남동쪽 힐팩 지대를 맡아 소규모 교전과 회복 루트를 챙깁니다.' }
];

const CONFIG = {
  game: { title: 'COSMIC LEAGUE', subtitle: '유니버설 파이터즈 서킷', saveKey: 'cosmic_league_save_v4' },
  nav: { select: '리그 선택', league: '리그', club: '구단 관리', market: '이적시장', codex: '파이터 도감', tactics: '전술', match: '경기장', data: '데이터 센터', trophy: '트로피' },

  /* ---------- 스탯 (도감 표시용) ---------- */
  statOrder: ['hp', 'mp', 'aspd', 'spd', 'atk', 'ap', 'def', 'res', 'ten', 'pen', 'ls', 'range', 'crit', 'critDmg'],
  stats: {
    hp:    { name: '체력',       short: '체력',   color: '#4ade80', max: 1100, digits: 0 },
    mp:    { name: '마나',       short: '마나',   color: '#38bdf8', max: 360,  digits: 0 },
    aspd:  { name: '공격속도',   short: '공속',   color: '#f97316', max: 1.4,  digits: 2 },
    spd:   { name: '이동속도',   short: '이속',   color: '#2dd4bf', max: 11,   digits: 1 },
    atk:   { name: '공격력',     short: '공격력', color: '#fb7185', max: 70,   digits: 0 },
    ap:    { name: '주문력',     short: '주문력', color: '#c084fc', max: 80,   digits: 0 },
    def:   { name: '방어력',     short: '방어력', color: '#60a5fa', max: 50,   digits: 0 },
    res:   { name: '저항력',     short: '저항력', color: '#a78bfa', max: 40,   digits: 0 },
    ten:   { name: '강인함',     short: '강인함', color: '#fbbf24', max: 0.6,  digits: 0, pct: true, tip: 'CC 지속시간 단축' },
    pen:   { name: '관통력',     short: '관통력', color: '#f43f5e', max: 0.3,  digits: 0, pct: true, tip: '방어력·저항력 무시' },
    ls:    { name: '생명력흡수', short: '흡수',   color: '#ef4444', max: 0.3,  digits: 0, pct: true, tip: '준 피해의 일부를 회복' },
    range: { name: '사거리',     short: '사거리', color: '#94a3b8', max: 30,   digits: 0 },
    crit:  { name: '치명타 확률', short: '치명타', color: '#facc15', max: 0.5,  digits: 0, pct: true, tip: '기본 공격이 치명타가 될 확률' },
    critDmg: { name: '치명타 피해', short: '치피',  color: '#fb923c', max: 2.5,  digits: 0, pct: true, tip: '치명타 시 피해 배율' }
  },

  /* ---------- 상태이상 (cc:true 는 강인함으로 지속시간 단축) ---------- */
  status: {
    slow:    { name: '둔화', cc: true,  desc: '이동속도 감소' },
    stun:    { name: '기절', cc: true,  desc: '행동불가' },
    root:    { name: '속박', cc: true,  desc: '이동불가' },
    silence: { name: '침묵', cc: true,  desc: '스킬불가' },
    poison:  { name: '중독', cc: false, desc: '마나 회복량 감소' },
    burn:    { name: '화상', cc: false, desc: '치유량 감소' },
    freeze:  { name: '빙결', cc: true,  desc: '둔화 및 피해량 감소' },
    fear:    { name: '공포', cc: true,  desc: '잠시 반대로 도망감' },
    knock:   { name: '넉백', cc: false, desc: '뒤로 밀려남' },
    stagger: { name: '경직', cc: true,  desc: '아주 짧게 이동 및 스킬 불가' },
    bleed:   { name: '출혈', cc: false, desc: '받는 피해 증가' },
    blind:   { name: '실명', cc: true,  desc: '기본 공격이 빗나감' }
  },
  statusFx: { slow: 0.3, poison: 0.5, burn: 0.5, freezeSlow: 0.35, freezeDmg: 0.8, bleed: 0.08 },

  roles: {
    warrior: { name: '전사',   icon: '⚔', color: '#ff7a59' },
    mage:    { name: '마법사', icon: '🔮', color: '#a78bfa' },
    guardian: { name: '수호자', icon: '🛡', color: '#38bdf8' },
    assassin: { name: '암살자', icon: '🗡', color: '#f43f5e' },
    hunter: { name: '사냥꾼', icon: '🎯', color: '#22c55e' }
  },

  /* ---------- 밴픽 ----------
     order: 토큰 'A:ban' 'B:pick' ... (A = 먼저 선택하는 팀 = 경기 대진의 앞쪽 팀)  지그재그(번갈아) 형식, 벤 1 · 픽 3 (팀당) */
  draft: {
    order: ['A:ban', 'B:ban', 'A:pick', 'B:pick', 'A:pick', 'B:pick', 'A:pick', 'B:pick'],
    aiDelayMs: 900
  },

  /* ---------- 전술 ----------
     개인 지시(categories): 파이터마다 설정. 팀 전략(team): 팀 전체에 적용. 모든 항목은 [선택지, 정도(1~7)] 로 저장됩니다.
     난이도는 파이터 개별 AI(이동·스킬·타게팅)를 바꾸지 않고, AI 팀이 '어떤 전술을 짜는가'만 바꿉니다. */
  tactics: {
    maxLevel: 7,
    phases: [40, 100],
    marginBase: 4, marginStep: 0.4,
    stances: {
      balanced:  { post: 1,    kill: 1,    boss: 1,    pod: 1,   hold: 1,   aggro: 0 },
      capture:   { post: 1.3,  kill: 0.9,  boss: 0.8,  pod: 1.5, hold: 1.2, aggro: -3 },
      slay:      { post: 0.7,  kill: 1.6,  boss: 0.85, pod: 0.85, hold: 0.75, aggro: 8 },
      objective: { post: 0.85, kill: 0.85, boss: 1.6,  pod: 1.3, hold: 0.95, aggro: 0 },
      defend:    { post: 1.1,  kill: 0.85, boss: 0.55, pod: 1.2, hold: 1.4, aggro: -3 }
    },
    categories: [
      { id: 'lane', name: '공격 진행', neutral: 'auto', options: [
        { id: 'auto',  name: '자동',     desc: '팀 전략·전장 상황에 맞춰 진행 방식을 고릅니다.' },
        { id: 'rush',  name: '중앙 돌진', desc: '보스 구덩이와 중앙 한타로 곧장 들어가 선제 교전을 엽니다.' },
        { id: 'flank', name: '우회 후 기습', desc: '외곽으로 돌아 힐팩을 챙기다가, 중앙 교전이나 보스전이 벌어지면 측면에서 기습합니다.' },
        { id: 'rear',  name: '후방 지원', desc: '아군이 모인 쪽 뒤에서 따라 움직이며 교전을 받쳐 줍니다.' },
        { id: 'boss',  name: '보스 대기', desc: '보스가 나오면 우선 합류합니다. 보스가 없을 때는 중앙 근처에서 대기합니다.' } ] },
      { id: 'duty', name: '주 임무', neutral: 'none', options: [
        { id: 'none',    name: '자유',     desc: '별도 임무 없이 팀 기조를 따릅니다.' },
        { id: 'capture', name: '오브젝트', desc: '보스와 중앙 확보가 최우선. 보스가 없으면 중앙 가장자리에서 대기합니다.' },
        { id: 'hunt',    name: '처치',     desc: '체력이 낮거나 고립된 적을 쫓아 킬 점수와 부활 공백을 노립니다.' },
        { id: 'guard',   name: '수비',     desc: '외곽 힐팩과 아군 회복 루트를 지키며 쫓아오는 적을 막아냅니다.' },
        { id: 'escort',  name: '호위',     desc: '아군 핵심 딜러 옆을 지키며 싸웁니다.' } ] },
      { id: 'act', name: '교전 태도', neutral: 'basic', options: [
        { id: 'basic',   name: '기본', desc: '파이터 고유 사거리·카이팅을 따릅니다.' },
        { id: 'rush',    name: '돌진', desc: '적에게 먼저 붙습니다. 이동속도↑ 방어력↓ (정도에 비례).' },
        { id: 'retreat', name: '카이팅', desc: '거리를 유지하며 싸웁니다. 정도가 높을수록 일찍 뒤로 빠집니다.' } ] },
      { id: 'fight', name: '팀플레이', neutral: 'none', options: [
        { id: 'none',    name: '단독', desc: '자기 목표를 우선합니다.' },
        { id: 'coop',    name: '집중', desc: '아군이 노리는 적을 함께 때립니다. 집중 공격 시 피해↑.' },
        { id: 'support', name: '지원', desc: '맞는 아군 쪽 적을 우선 끊고, 위급한 아군 쪽으로 붙습니다.' },
        { id: 'solo',    name: '고립 사냥', desc: '타겟을 오래 유지합니다. 주변에 아군이 없을 때 공격력↑.' } ] },
      { id: 'pos', name: '대열 위치', neutral: 'none', options: [
        { id: 'none',  name: '기본', desc: '파이터 기본 포지션을 따릅니다.' },
        { id: 'front', name: '전방', desc: '아군보다 앞에서 교전을 엽니다. 보스 진입·선제 교전에 유리합니다.' },
        { id: 'cover', name: '후방', desc: '아군 뒤·엄폐물 쪽에서 딜합니다. 암살·누킹에 덜 노출됩니다.' } ] },
      { id: 'aim', name: '표적 우선', neutral: 'near', options: [
        { id: 'near',   name: '가까운 적', desc: '가장 가까운 적을 기본 목표로 잡습니다.' },
        { id: 'weak',   name: '체력 낮은 적', desc: '체력 비율이 낮은 적을 우선해 처치를 노립니다.' },
        { id: 'back',   name: '후방 딜러', desc: '마법사·원거리 등 뒤쪽 딜러를 우선합니다.' },
        { id: 'carry',  name: '고화력', desc: '공격력·주문력이 높은 적을 우선합니다.' },
        { id: 'capper', name: '보스 딜러', desc: '보스를 치고 있는 적을 우선해 막타 스틸과 견제를 노립니다.' } ] },
      { id: 'ult', name: '궁극기 타이밍', neutral: 'normal', options: [
        { id: 'normal', name: '효율',     desc: '다수 적중·위급 아군 등 효율 좋은 타이밍에 씁니다.' },
        { id: 'burst',  name: '즉시',     desc: '쿨이 오면 바로 씁니다. 정도 3↑ 이면 조건이 더 느슨해집니다.' },
        { id: 'save',   name: '한타·보스', desc: '적이 모였거나 보스 근처, 아군 위급할 때만 씁니다.' },
        { id: 'clutch', name: '위기 아낌', desc: '아군 체력이 위험할 때까지 아끼다 씁니다.' } ] }
    ],
    team: [
      { id: 'stance', group: '운영', name: '운영 기조', neutral: 'balanced', options: [
        { id: 'balanced',  name: '균형',     desc: '교전·보스·회복 루트를 상황에 맞게 고르게 봅니다.' },
        { id: 'capture',   name: '힐 장악',  desc: '힐팩 루트를 장악해 회복 싸움에서 앞서 갑니다. 무리한 추격은 줄입니다.' },
        { id: 'slay',      name: '처치 우선', desc: '킬과 전멸을 노려 점수·부활 공백을 만듭니다. 보스 대응이 늦어지기 쉽습니다.' },
        { id: 'objective', name: '오브젝트',  desc: '중앙 보스와 회복팩을 우선해 한 방에 판을 뒤집습니다.' },
        { id: 'defend',    name: '수비 우선', desc: '무리하게 나서지 않고 목숨을 아끼며 버팁니다. 리드 중 굳히기에 적합합니다.' } ] },
      { id: 'boss', group: '운영', name: '보스 방침', neutral: 'smart', options: [
        { id: 'smart',   name: '상황 판단', desc: '점수 차·위치를 보고 보스 합류·유인(함정)·대기를 정합니다.' },
        { id: 'contest', name: '적극 도전', desc: '보스가 나오면 적극적으로 갑니다. 정도가 높을수록 더 많은 인원이 붙습니다.' },
        { id: 'yield',   name: '양보',     desc: '보스는 포기하고 킬 점수에 집중합니다.' },
        { id: 'steal',   name: '스틸',     desc: '중앙 가장자리에서 대기하다 상대가 보스 체력을 깎으면 끼어들어 막타를 노립니다.' } ] },
      { id: 'formation', group: '운영', name: '병력 운용', neutral: 'auto', options: [
        { id: 'auto',  name: '자동',   desc: '목표 가치에 따라 자연스럽게 나뉩니다.' },
        { id: 'group', name: '집결',   desc: '가능하면 같이 붙어 한타·보스에 힘을 모읍니다.' },
        { id: 'split', name: '분산',   desc: '중앙·북서·남동으로 흩어져 곳곳에서 교전과 추격전을 만듭니다.' },
        { id: 'lanes', name: '라인 분담', desc: '1·2·3픽 공격 진행 지시에 맞춰 진행 방식을 나눕니다.' } ] },
      { id: 'retreat', group: '운영', name: '열세 대응', neutral: 'careful', options: [
        { id: 'careful', name: '신중', desc: '수적·체력 열세면 무리한 교전을 피합니다.' },
        { id: 'brave',   name: '강행', desc: '불리해도 교전·보스를 밀어붙입니다.' } ] },
      { id: 'ultT', group: '운영', name: '팀 궁 기조', neutral: 'normal', options: [
        { id: 'normal', name: '기본',       desc: '개인 궁 지시가 우선. 없으면 효율 타이밍에 씁니다.' },
        { id: 'burst',  name: '즉시 투하',   desc: '쿨이 오면 빨리 쓰도록 팀 전체가 느슨한 조건을 씁니다.' },
        { id: 'save',   name: '한타·보스 보존', desc: '큰 교전·보스 타이밍까지 궁을 아낍니다.' },
        { id: 'clutch', name: '위기 대응',   desc: '아군이 위험할 때 쓰기 쉽게 맞춥니다.' } ] },
      /* 팀 교전 (신규): 모든 항목의 첫 선택지가 중립값이며 예전 동작과 같습니다. 정도(1~7)의 의미는 각 항목 설명 참고 */
      { id: 'gather', group: '교전', name: '진입 기준 인원', neutral: 'free', options: [
        { id: 'free',  name: '각자 이동', desc: '집결하지 않고 각자 목표로 움직입니다.' },
        { id: 'two',   name: '2명 집결', desc: '적이 가까우면 아군 2명이 모일 때까지 안전 지점에서 기다렸다가 같이 진입합니다. 정도가 높을수록 더 바짝 모여야 합니다.' },
        { id: 'three', name: '3명 집결', desc: '3명이 모일 때까지 기다렸다가 전원이 같이 진입합니다. 정도가 높을수록 더 바짝 모여야 합니다.' } ] },
      { id: 'hurry', group: '교전', name: '성급함', neutral: 'normal', options: [
        { id: 'normal',  name: '보통', desc: '집결을 최대 약 5초 기다린 뒤 풀려서 교전합니다.' },
        { id: 'patient', name: '차분', desc: '집결을 더 오래 기다립니다. 정도가 높을수록 길어집니다(최대 약 15초).' },
        { id: 'rash',    name: '성급', desc: '집결을 빨리 포기하고 진입합니다. 정도가 높을수록 짧아집니다(최소 약 1.2초).' } ] },
      { id: 'focus', group: '교전', name: '팀 포커스 타깃', neutral: 'own', options: [
        { id: 'own',    name: '각자 판단', desc: '각자 가까운 적을 노립니다.' },
        { id: 'weak',   name: '약한 적',   desc: '팀 전체가 체력이 낮은 적을 먼저 노립니다. 정도가 높을수록 타깃을 강하게 따릅니다.' },
        { id: 'threat', name: '위협 큰 적', desc: '공격력과 위협도가 큰 적을 먼저 노립니다.' },
        { id: 'back',   name: '후열·지원',  desc: '후열 딜러와 보호막·강화를 쓰는 지원형 적을 먼저 노립니다.' } ] },
      { id: 'chain', group: '교전', name: '궁 연계', neutral: 'off', options: [
        { id: 'off',    name: '연계 없음', desc: '궁 타이밍은 각자의 궁 설정에 따릅니다.' },
        { id: 'follow', name: '같이 진입', desc: '아군이 궁을 쓰면 잠시 다른 아군의 궁 사용 문턱이 낮아지고 집결 대기가 풀려 함께 진입합니다. 정도가 높을수록 오래 지속됩니다.' } ] },
      { id: 'roleMove', group: '교전', name: '역할별 이동', neutral: 'free', options: [
        { id: 'free',  name: '각자', desc: '역할 구분 없이 움직입니다.' },
        { id: 'split', name: '역할 분담', desc: '전열이 먼저 들어가고 후열은 전열 뒤에서 간격을 유지하며, 암살자는 측면으로 우회합니다. 구역 밖에서도 적을 따라가 싸웁니다. 정도가 높을수록 간격·우회 폭·추격 범위가 커집니다.' } ] },
      { id: 'podCycle', group: '교전', name: '회복팩 순환', neutral: 'off', options: [
        { id: 'off',   name: '각자', desc: '회복하러 가는 사람과 무관하게 움직입니다.' },
        { id: 'cover', name: '함께 물러남', desc: '아군이 회복팩을 먹으러 가면 나머지는 잠시 물러났다가 복귀 후 같이 재진입합니다. 정도가 높을수록 물러나 있는 시간이 깁니다.' } ] },
      { id: 'early', group: '시간대', name: '초반 (0~40초)', noLevel: true, neutral: 'follow', options: [] },
      { id: 'mid', group: '시간대', name: '중반 (40~100초)', noLevel: true, neutral: 'follow', options: [] },
      { id: 'late', group: '시간대', name: '후반 (100초~)', noLevel: true, neutral: 'follow', options: [] },
      { id: 'lead', group: '점수 차', name: '앞서면', neutral: 'keep', options: [
        { id: 'keep',   name: '유지',     desc: '기조를 바꾸지 않습니다.' },
        { id: 'turtle', name: '굳히기',   desc: '점수 차가 벌어지면 수비 기조로 전환해 목숨을 아낍니다.' },
        { id: 'press',  name: '마무리',   desc: '점수 차가 벌어지면 처치 기조로 끝장을 봅니다.' } ] },
      { id: 'trail', group: '점수 차', name: '뒤처지면', neutral: 'keep', options: [
        { id: 'keep',   name: '유지',     desc: '기조를 바꾸지 않습니다.' },
        { id: 'gamble', name: '승부수',   desc: '보스 또는 처치 기조로 한 방을 노립니다.' },
        { id: 'steady', name: '차근 소모전', desc: '무리하지 않고 힐 장악으로 소모전을 걸어 점수를 따라갑니다.' } ] },
      { id: 'react', group: '점수 차', name: '판단력', neutral: 'adapt', options: [
        { id: 'fixed', name: '고정',     desc: '짜 둔 계획만 따릅니다. 판단이 느립니다.' },
        { id: 'adapt', name: '점수·시간', desc: '점수 차와 남은 시간을 보고 기조를 바꿉니다.' },
        { id: 'smart', name: '적 읽기',   desc: '적의 보스 딜·불리한 교전 회피·보스 스틸·유인까지 봅니다.' } ] }
    ],
    p: {
      rushSpd: 0.025, rushDef: 0.02,
      retreatHp0: 0.3, retreatHpStep: 0.1, retreatBase: 5, retreatMul: 0.9, retreatAdd: 4,
      coopBias: 0.5, coopDmg: 0.018, supportBias: 0.65, assistWindow: 40, assistBase: 8, assistStep: 2.5,
      soloStick: 3, soloAtk: 0.02, soloAlone: 20,
      frontBase: 0.4, frontStep: 0.035, coverHide: 0.16, coverBack: 2, coverStep: 0.6, aimBias: 0.7, clutchHp0: 0.2, clutchHpStep: 0.06,
      laneBonus: 0.2, laneStep: 0.55, laneMiss: 0.1,
      dutyCap: 0.3, dutyHunt: 0.45, dutyGuard: 0.3, dutyAggroCap: 0, dutyAggroHunt: 3, escortDist: 7, capperBias: 0.7,
      groupBonus: 0.45, splitPenalty: 0.9, retreatThr: 0.4, retreatThrStep: 0.04, podReach: 110
    }
  },

  /* ---------- AI 난이도 ----------
     파이터 개별 AI(이동·스킬·타게팅)는 모든 난이도에서 동일합니다. 난이도는 AI 팀이 짜는 팀 전략/개인 지시의 수준만 바꿉니다. */
  ai: {
    default: 'normal',
    levels: {
      easy:   { name: '쉬움',   desc: '계획 없이 움직입니다. 보스를 포기하고, 상황 변화에 둔하고, 체력이 줄어도 버팁니다.' },
      normal: { name: '보통',   desc: '균형 잡힌 기조에 점수·시간을 보고 기조를 바꿉니다.' },
      hard:   { name: '어려움', desc: '적의 보스 교전을 읽고 스틸·유인으로 대응합니다. 파이터 역할에 맞춰 임무를 나눕니다.' },
      master: { name: '마스터', desc: '상대 편성에 맞춰 기조를 정하고, 보스를 가로채며, 점수 차·남은 시간·서든데스까지 계산해 움직입니다.' }
    }
  },

  /* ---------- 전투 ---------- */
  battle: {
    tickMs: 50, maxTicks: 3600, retargetTicks: 12,
    arena: { w: 225, h: 150 }, unitRadius: 2.2,
    aggro: 26,
    respawn: { base: 6, perDeath: 1.5, max: 14, protect: 2 },
    damage: { variance: 0.08 },
    hpScale: 1.45,
    speeds: [1, 2, 4],
    mana: { regenPerSec: 0.05, onHit: 4, onHurt: 3, startRatio: 0.4 },
    map: {
      killPoints: 1, acePoints: 2,
      sudden: { hpRatio: 0.35, maxTicks: 1200, protect: 3, pressSec: 30 },
      spawns: [ { pts: [[20, 125], [28, 130], [21, 133]] }, { pts: [[205, 25], [197, 20], [204, 17]] } ],
      zones: MAP_ZONES,
      lanes: MAP_ROADS,
      jungles: [], parks: MAP_PARKS,
      obstacles: MAP_OBSTACLES,
      pods: [
        { x: 14,    y: 14,  heal: 0.4, cd: 20, big: true }, { x: 211,   y: 136, heal: 0.4, cd: 20, big: true },
        { x: 112.5, y: 10,  heal: 0.4, cd: 20, big: true }, { x: 112.5, y: 140, heal: 0.4, cd: 20, big: true },
        { x: 10,    y: 75,  heal: 0.4, cd: 20, big: true }, { x: 215,   y: 75,  heal: 0.4, cd: 20, big: true },
        { x: 62,    y: 105, heal: 0.3, cd: 20 },            { x: 163,   y: 45,  heal: 0.3, cd: 20 }
      ],
      bosses: [
        { kind: 'mid',  def: 'golem', at: 40, warn: 8, points: 3, hpMul: 1 },
        { kind: 'late', def: 'titan', after: 40, warn: 8, points: 5, hpMul: 1 }
      ],
      lairs: [ { x: MAP_CX, y: MAP_CY } ]
    },
    skillStartCdRatio: 0.3, ultStartCdRatio: 0.4
  },

  /* ---------- 리그 ----------
     6개 리그: 난이도(AI 팀 전술 수준)가 다릅니다. 전투 캐릭터 능력치 보정(bonus·시즌 성장)은 없습니다. 플레이어는 감독이 되어 리그의 팀 하나를 고릅니다.
     정규시즌 rounds 라운드 → 중간(midRound)에 MSI → 시즌 종료 후 플레이오프 → 월드 챔피언십. 국제대회는 리그별 상위 intlTeams 팀이 참가합니다. */
  league: {
    teamCount: 12, rounds: 24, midRound: 12,           // 12팀 더블 라운드로빈(22) + 2라운드 = 팀당 24경기
    ptsWin: 3, ptsDraw: 1, ptsLoss: 0,
    playoffTeams: 8, intlTeams: 4,
    aiFavorites: 5,                                   // AI 팀이 선호하는 파이터 수
    roundNames: { 2: '결승', 4: '준결승', 8: '8강', 16: '16강', 32: '32강' },
    playoffName: '플레이오프',
    intl: { msi: { name: 'MSI', full: '미드시즌 인비테이셔널' }, worlds: { name: '월드 챔피언십', full: '월드 챔피언십' } },
    cupRules: [   // 국제대회 때 무작위 1개 적용. hpMul atkMul apMul defMul spdMul aspdMul mpMul
      { name: '저중력 경기장', desc: '이동속도 +30%', spdMul: 1.3 },
      { name: '과부하 코어',   desc: '공격력·주문력 +15% / 체력 -10%', atkMul: 1.15, apMul: 1.15, hpMul: 0.9 },
      { name: '마나 폭풍',     desc: '마나 회복 2배', mpMul: 2 },
      { name: '가속 필드',     desc: '공격속도 +25%', aspdMul: 1.25 },
      { name: '강화 장갑',     desc: '방어력·저항력 +30%', defMul: 1.3 }
    ]
  },
  leagues: [
    { id: 'sea', name: '동남아', short: 'SEA', color: '#34d399', diff: 'easy', desc: '입문 리그. AI 팀의 전술이 단순합니다.',
      teams: ['방콕 나가', '자카르타 가루다', '마닐라 아길라', '쿠알라룸푸르 트윈', '싱가포르 머라이언', '하노이 롱', '호치민 사이공', '세부 코랄', '발리 서프', '치앙마이 오키드', '프놈펜 앙코르', '양곤 파고다'] },
    { id: 'jp', name: '일본', short: 'JP', color: '#f472b6', diff: 'normal', desc: '균형 잡힌 AI. 점수와 시간을 보고 기조를 바꿉니다.',
      teams: ['도쿄 사쿠라', '오사카 쇼군', '교토 토리이', '요코하마 미나토', '나고야 샤치', '삿포로 유키', '후쿠오카 하카타', '센다이 다테', '고베 카이', '히로시마 모미지', '나라 시카', '가나자와 킨'] },
    { id: 'na', name: '북미', short: 'NA', color: '#60a5fa', diff: 'normal', desc: '다양한 편성이 나오는 리그. 변수가 많습니다.',
      teams: ['로스앤젤레스 코멧', '뉴욕 타이탄', '시카고 윈드', '시애틀 레인', '토론토 노스', '댈러스 아웃로', '마이애미 플레어', '보스턴 패트리어트', '덴버 서밋', '애틀랜타 피치', '밴쿠버 오션', '피닉스 듄'] },
    { id: 'eu', name: '유럽', short: 'EU', color: '#a78bfa', diff: 'hard', desc: '적의 움직임을 읽고 보스를 가로채는 영리한 AI.',
      teams: ['베를린 발키리', '런던 나이츠', '파리 에클레르', '마드리드 솔라', '로마 센츄리온', '암스테르담 오션', '스톡홀름 아이스', '바르샤바 이글스', '프라하 클락', '빈 심포니', '리스본 카라벨', '코펜하겐 바이킹'] },
    { id: 'cn', name: '중국', short: 'CN', color: '#f87171', diff: 'hard', desc: '전술이 날카로운 강팀들의 리그.',
      teams: ['상하이 드래곤즈', '베이징 피닉스', '광저우 타이거즈', '선전 사이버', '청두 판다 크루', '항저우 네오', '우한 썬더', '시안 레전드', '난징 블레이드', '충칭 인페르노', '톈진 글로리', '칭다오 웨이브'] },
    { id: 'kr', name: '한국', short: 'KR', color: '#fbbf24', diff: 'master', desc: '최고 난이도. 편성을 읽고 승부수와 굳히기를 정확히 합니다.',
      teams: ['서울 아스트라', '부산 오로라', '인천 노바', '대구 베가', '광주 시리우스', '대전 퀘이사', '울산 헬리오스', '수원 스펙트라', '제주 루나', '전주 오리온', '창원 파이로', '성남 비전'] }
  ],
  news: {
    analysis: {                                       // 경기 후 전투 분석 칼럼 (News.analysis)
      mode: 'chance',                                 // 'all' 내 경기 전부 · 'important' 중요 경기만 · 'chance' 중요 경기 + 일반 경기는 확률 · 'off' 끔
      chance: 0.4,                                    // mode 'chance' 일 때 일반 경기에서 생성될 확률
      bigDiff: 6,                                     // 최종 점수 차가 이 값 이상이면 중요 경기 (플레이오프·MSI·월즈·서든데스는 항상 중요)
      fightSec: 10, fightMin: 3,                      // 한타 판정: 이 시간(초) 안에 처치가 이 수 이상
      leadGap: 3,                                     // 이 점수 차 이상 앞섰다가/뒤졌다가 뒤집히면 '역전' 으로 서술
      slumpDeaths: 3, slumpShare: 0.2, slumpDeath: 0.15,   // 부진 판정: 데스 수 · 팀 기여도 하한 · 데스 1회당 기여도 감점
      tankShare: 0.4,                                 // 받은 피해가 팀 전체의 이 비율 이상이면 전열 서술
      rushDeaths: 3, deathsHigh: 6, ultLow: 1,        // 개인 지시 실패 데스 수 · 팀 데스 많음 · 궁극기 사용 적음 기준
      maxTactic: 2, maxTask: 2,                       // 전술 평가의 개인 지시 문장 수 · 다음 과제 문장 수
      counter: {                                      // 상성표: 키 역할이 값 역할들에게 유리 (밴픽 카운터 서술용)
        assassin: ['mage', 'hunter'], mage: ['hunter', 'warrior'], hunter: ['warrior', 'guardian'],
        warrior: ['guardian', 'assassin'], guardian: ['assassin', 'mage']
      }
    }
  },
  trophies: {
    league: { name: '리그 우승', icon: '🏆' },
    msi:    { name: 'MSI 우승', icon: '🥇' },
    worlds: { name: '월드 챔피언십 우승', icon: '👑' }
  },

  /* ---------- 전투 AI 지능 단계 (프로게이머 C~S급) ----------
     파이터 개별 전투 AI 의 '판단력'입니다. 팀 전체는 teams[i].brain, 파이터별은 teams[i].brains[idx] 에 'C'|'B'|'A'|'S' 를 넣으면 됩니다. 기본은 default.
     chaseT: 도망가는 적을 따라잡지 못하고 쫓는 최대 시간(초)  leash: 쫓는 최대 거리  retreatHp: 이 체력 비율 아래면 즉시 후퇴·재정비
     ratio: 주변 적 전력 ÷ 아군 전력이 이 값을 넘으면 싸우지 않고 기다림(99=판단 안 함)  podRun: 체력이 낮을 때 이 거리 안의 힐팩이 있으면 교전 중에도 먹으러 감
     ensureBoss: 모두가 추격에 몰려도 보스 타이밍에는 한 명은 중앙으로  waitPod: 회복 장치가 다시 나올 때까지 기다렸다 회복 */
  brain: {
    default: 'A',
    /* 등급별 기본 행동. 등급 사이 격차는 일부러 작게 두었습니다(C급도 S급을 이길 수 있게).
       시험 결과 '무조건 조심스러운' 설정(열세 시 대기·이른 후퇴)은 승률이 오히려 낮아, 등급 차이를 소극성이 아닌 점령·회복·스킬 회전의 효율로 두었습니다.
       실제 차이는 아래 stat 의 세부 능력치(선수마다 다름)에서 생깁니다.
       chaseT/leash: 추격 시간·거리  retreatHp: 후퇴 체력비  ratio: 수적·전력 열세 허용 배율(클수록 무모)
       podRun: 교전 중 점령지로 달려가는 거리  ensureBoss: 점령 놓치지 않기  waitPod: 회복 장치 대기
       skillPatience: 쿨타임이 돈 스킬을 '더 좋은 순간'을 기다리는 시간(초) — 짧을수록 스킬 회전이 빠릅니다(시험 결과 빠를수록 유리)
       recastHold: 재시전을 기다리는 신중함(초) */
    levels: {
      C: { name: 'C급', desc: '오래 쫓다가 보스 타이밍을 놓치기 쉽고, 스킬 타이밍이 늦습니다.',
           chaseT: 8, leash: 48, retreatHp: 0.21, ratio: 3.2, podRun: 16, ensureBoss: false, waitPod: false, skillPatience: 2.4, recastHold: 0.9 },
      B: { name: 'B급', desc: '적당히 쫓다 돌아오고, 힐팩을 가끔 챙깁니다.',
           chaseT: 7, leash: 44, retreatHp: 0.22, ratio: 3.4, podRun: 28, ensureBoss: false, waitPod: false, skillPatience: 2.0, recastHold: 0.95 },
      A: { name: 'A급', desc: '보스 타이밍을 챙기고, 스킬을 비교적 빠르게 돌립니다.',
           chaseT: 6, leash: 40, retreatHp: 0.22, ratio: 3.6, podRun: 40, ensureBoss: true, waitPod: false, skillPatience: 1.6, recastHold: 1.0 },
      S: { name: 'S급', desc: '보스 타이밍과 회복 장치를 놓치지 않고, 스킬을 쿨이 돌자마자 씁니다.',
           chaseT: 5.5, leash: 38, retreatHp: 0.23, ratio: 3.8, podRun: 50, ensureBoss: true, waitPod: true, skillPatience: 1.3, recastHold: 1.1 }
    },
    /* 선수 세부 능력치 → 전투 행동 보정.
       능력치 값을 (값 - center) / range 로 -1~+1 로 바꾼 뒤, 아래 항목을 [행동값, 'mul'(곱: 1 + k*n) | 'add'(더하기: k*n), k] 로 적용합니다.
       항목을 고치거나 추가하면 자동 반영됩니다. defaults 는 등급 값에 없는 행동의 기본값입니다. */
    stat: {
      center: 65, range: 35,
      defaults: { finish: 0, assist: 0, whiff: 0.05, ultWait: 6, retargetMul: 1, moodGuard: 0 },
      whiffKinds: ['nuke', 'pierce', 'aoe', 'charge'],          // 스킬샷 정확도가 영향을 주는 스킬 종류 (대상이 있는 공격 스킬)
      limits: { finish: [0, 0.4], assist: [0, 0.3], retreatHp: [0.1, 0.55], ratio: [1.05, 6], leash: [18, 80], chaseT: [1.2, 14], podRun: [0, 90], skillPatience: [0.5, 4], recastHold: [0.3, 1.6], whiff: [0, 0.22], ultWait: [2.5, 12], retargetMul: [0.5, 1.5], moodGuard: [-0.25, 0.4] },
      fx: {
        judge:  [['chaseT', 'mul', -0.12], ['skillPatience', 'add', -0.4]],
        posn:   [['retreatHp', 'add', 0.04]],
        obj:    [['podRun', 'mul', 0.15]],
        team:   [['assist', 'add', 0.15]],
        react:  [['retargetMul', 'mul', -0.25]],
        aim:    [['whiff', 'add', -0.09]],
        ult:    [['ultWait', 'add', -3]],
        fight:  [['finish', 'add', 0.25]],
        clutch: [['moodGuard', 'add', 0.4]]
      },
      objHi: 75, objLo: 40
    }
  },

  /* ---------- 프로게이머 / 구단 ----------
     등급(C~S)은 전투 AI 지능 단계(CONFIG.brain)와 같습니다. 1번/2번/3번 라인업 = 첫째/둘째/셋째 픽 파이터를 맡는 선수 */
  pro: {
    grades: {
      C: { name: 'C급', color: '#94a3b8', salary: [300, 600],   ovr: [40, 59] },
      B: { name: 'B급', color: '#60a5fa', salary: [700, 1300],  ovr: [60, 74] },
      A: { name: 'A급', color: '#c084fc', salary: [1500, 2600], ovr: [75, 89] },
      S: { name: 'S급', color: '#fbbf24', salary: [3000, 4800], ovr: [90, 99] }
    },
    styles: [ { id: 'balanced', name: '균형형' }, { id: 'capture', name: '힐 장악형' }, { id: 'slay', name: '교전형' }, { id: 'objective', name: '오브젝트형' }, { id: 'defend', name: '수비형' } ],
    contract: [1, 3],
    /* 세부 능력치 (선수 카드 뒷면). 항목을 추가/삭제하려면 이 목록만 고치면 자동 반영됩니다 */
    skills: [
      { id: 'aim',    name: '스킬샷 정확도', icon: '🎯', desc: '대상을 노리는 공격 스킬이 빗나갈 확률이 줄어듭니다' },
      { id: 'judge',  name: '판단력',        icon: '🧠', desc: '쫓아가다 포기할 때를 알고, 스킬을 놓치지 않고 바로 씁니다' },
      { id: 'fight',  name: '교전 능력',     icon: '⚔️', desc: '체력이 깎인 적을 놓치지 않고 마무리합니다(캐릭터 능력치에는 영향 없음)' },
      { id: 'react',  name: '반응속도',      icon: '⚡', desc: '목표를 바꾸는 속도 — 약해진 적·위협적인 적을 빨리 노립니다' },
      { id: 'posn',   name: '포지셔닝',      icon: '📍', desc: '위험해지기 전에 물러나는 체력 기준이 높아집니다(낮으면 끝까지 버팁니다)' },
      { id: 'ult',    name: '궁극기 운용',   icon: '💥', desc: '궁극기를 좋은 때를 기다리지 않고 더 일찍 씁니다' },
      { id: 'obj',    name: '오브젝트·회복', icon: '🚩', desc: '보스 타이밍과 힐팩을 놓치지 않고, 교전 중에도 필요하면 달려갑니다' },
      { id: 'team',   name: '팀워크',        icon: '🤝', desc: '아군을 때린 적을 먼저 견제합니다' },
      { id: 'clutch', name: '클러치·침착성', icon: '🧊', desc: '낮은 폼·멘탈, 트러블이 AI 판단에 주는 악영향을 줄여줍니다' }
    ],
    /* 교전 스타일: 선수 본인 평균 대비 강점이 가중합으로 가장 크게 나타나는 쪽으로 자동 결정 */
    engage: [
      { id: 'initiator', name: '선제 돌입형', desc: '먼저 파고들어 교전을 엽니다', w: { fight: 0.5, react: 0.3, clutch: 0.2 } },
      { id: 'counter',   name: '카운터형',    desc: '상대 진입을 받아치는 데 능합니다', w: { judge: 0.45, posn: 0.3, react: 0.25 } },
      { id: 'poke',      name: '견제·포킹형', desc: '거리를 두고 스킬로 체력을 깎습니다', w: { aim: 0.55, posn: 0.3, judge: 0.15 } },
      { id: 'safe',      name: '안정 교전형', desc: '아군과 보조를 맞추며 손해를 피합니다', w: { team: 0.4, judge: 0.3, posn: 0.3 } },
      { id: 'allin',     name: '올인 돌격형', desc: '궁극기와 함께 승부를 거는 공격형입니다', w: { fight: 0.4, ult: 0.4, clutch: 0.3, judge: -0.1 } }
    ],
    /* 희귀도: 모든 능력치가 perfectMin 이상이면 '완벽한 재능', 평균이 aceAvg 이상이면 '에이스'. perfectChance 는 등급별 완벽 재능 확률 */
    rarity: { perfectMin: 90, aceAvg: 96 },
    skillGen: { perfectChance: { S: 0.015, A: 0, B: 0, C: 0 }, specialistChance: 0.15 },     // 완벽한 재능은 S급 중 1.5%만 / 특화 재능은 전 등급 15%
    aiMix: { easy: { C: 0.5, B: 0.4, A: 0.1, S: 0 }, normal: { C: 0.2, B: 0.45, A: 0.3, S: 0.05 }, hard: { C: 0.05, B: 0.3, A: 0.45, S: 0.2 }, master: { C: 0, B: 0.15, A: 0.45, S: 0.4 } },
    market: { faSize: 16, listedSize: 6, refreshRounds: 6, feeMul: [1.4, 2.2], signMul: 0.4, releaseMul: 0.5, renewMul: 0.3, renewRaise: 0.08 },
    names: {
      nick: ['Vex', 'Noir', 'Rin', 'Kairos', 'Mizu', 'Hana', 'Zephyr', 'Lumi', 'Orca', 'Draco', 'Nova', 'Echo', 'Jett', 'Kuro', 'Sora', 'Ryu', 'Blitz', 'Cipher', 'Dusk', 'Ember', 'Frost', 'Glitch', 'Haze', 'Iris', 'Jinx', 'Kite', 'Lynx', 'Mako', 'Nyx', 'Onyx', 'Pixel', 'Quill', 'Raze', 'Sable', 'Talon', 'Umbra', 'Volt', 'Wisp', 'Xeno', 'Yuki', 'Zero', '하늘', '새벽', '라온', '도윤', '시우', '바람', '하랑', '이든', '로아', '태오', '아린', '단비', '누리', '한결', '보람', '가온', '다온'],
      tail: ['Jr', 'X', '7', '99'],
      sur: ['김', '이', '박', '최', '정', '강', '조', '윤', '장', '임', '한', '오', '서', '신', '권', '황', '안', '송', '류', '홍'],
      given: ['민준', '서준', '도윤', '시우', '주원', '하준', '지호', '준우', '현우', '예준', '건우', '우진', '선우', '지훈', '승현', '유찬', '태윤', '은우', '이안', '정우'],
      nation: {
        kr:  { nick: ['Haneul', 'Baram', 'Dokkaebi', 'Sunwoo', 'Byeol', 'Mirae', 'Hwarang', 'Seol', 'Garam', 'Nuri'] },
        jp:  { nick: ['Kaze', 'Tsuki', 'Hayate', 'Shinobi', 'Kitsune', 'Sakura', 'Raiden', 'Yuki', 'Ronin', 'Akatsuki'],
               sur: ['佐藤', '鈴木', '高橋', '田中', '伊藤', '渡辺', '山本', '中村', '小林', '加藤'], given: ['蓮', '翔', '大和', '陽翔', '悠真', '颯太', '湊', '樹', '拓海', '蒼'] },
        cn:  { nick: ['Longwei', 'Xingyao', 'Tianlang', 'Feiyan', 'Baihu', 'Qilin', 'Yunfei', 'Mochen', 'Zhanlu', 'Fenghuang'],
               sur: ['王', '李', '张', '刘', '陈', '杨', '赵', '黄', '周', '吴'], given: ['浩然', '子轩', '宇航', '思远', '俊杰', '梓睿', '天宇', '明哲', '博文', '嘉豪'] },
        sea: { nick: ['Naga', 'Garuda', 'Harimau', 'Bayan', 'Kris', 'Lotus', 'Mekong', 'Typhoon', 'Rimau', 'Surya'],
               sur: ['Nguyen', 'Tran', 'Le', 'Pham', 'Somchai', 'Wong', 'Santos', 'Tan', 'Lim', 'Reyes'], given: ['Minh', 'Anh', 'Duc', 'Bao', 'Khoa', 'Arif', 'Rizky', 'Nattapon', 'Jericho', 'Kai'] },
        na:  { nick: ['Maverick', 'Ranger', 'Outlaw', 'Rocket', 'Stetson', 'Titan', 'Hawk', 'Bronco', 'Rebel', 'Ghost'],
               sur: ['Smith', 'Johnson', 'Miller', 'Davis', 'Garcia', 'Martinez', 'Anderson', 'Taylor', 'Moore', 'Clark'], given: ['Ethan', 'Mason', 'Logan', 'Noah', 'Tyler', 'Jordan', 'Caleb', 'Ryan', 'Diego', 'Austin'] },
        eu:  { nick: ['Viking', 'Valkyrie', 'Baron', 'Rapier', 'Sigurd', 'Aegis', 'Fjord', 'Gallus', 'Nordic', 'Templar'],
               sur: ['Müller', 'Jensen', 'Kowalski', 'Rossi', 'Novak', 'Dubois', 'Larsen', 'Silva', 'Ivanov', 'Andersson'], given: ['Lukas', 'Mikkel', 'Jan', 'Marco', 'Pierre', 'Erik', 'Tomas', 'Luca', 'Henrik', 'Matteo'] }
      },
      leagueMix: {
        kr:  { kr: 0.9, cn: 0.05, sea: 0.03, jp: 0.02 },
        cn:  { cn: 1 },
        jp:  { jp: 0.84, kr: 0.12, cn: 0.04 },
        sea: { sea: 0.62, kr: 0.2, jp: 0.06, cn: 0.06, na: 0.03, eu: 0.03 },
        na:  { na: 0.5, kr: 0.22, eu: 0.12, cn: 0.1, sea: 0.06 },
        eu:  { eu: 0.45, kr: 0.2, na: 0.12, cn: 0.15, sea: 0.04, jp: 0.04 }
      },
      foreignMax: { kr: 1, cn: 0, jp: 1, sea: 2, na: 2, eu: 2 }
    }
  },

  /* 스폰서/광고: 평판이 높을수록 제안 확률·금액↑. 수락 시 즉시 입금 */
  sponsor: {
    minRep: 55,                 // 이 미만이면 제안 안 옴
    cooldownRounds: 3,          // 제안/계약 후 최소 간격(라운드)
    chance: [                   // 평판 구간별 제안 확률
      { rep: 55, p: 0.18 },
      { rep: 70, p: 0.32 },
      { rep: 85, p: 0.48 }
    ],
    // 금액 = base * leagueMul * tierMul * (0.85~1.15 랜덤)
    base: 400,
    tierMul: [
      { rep: 55, mul: 1.0, label: '소형 광고' },
      { rep: 70, mul: 1.8, label: '공식 스폰서' },
      { rep: 85, mul: 3.0, label: '메인 스폰서' }
    ],
    leagueMul: { easy: 0.85, normal: 1, hard: 1.15, master: 1.3 },
    brands: [
      '네뷸라 에너지', '오비트 기어', '퀀텀칩', '스타링크 모바일', '코스믹 드링크',
      '갤럭시 뱅크', '하이퍼카 코리아', '루나 스포츠', '에이펙스 헤드셋', '보이드 스트리밍'
    ]
  },
  club: {
    currency: '크레딧', maxRoster: 6,
    startFunds: { easy: 5200, normal: 6000, hard: 7500, master: 9000 },
    /* 구단주 지급액 배율: 시작 선수단 연봉(리그 수준별 AI 등급 분포)과 4위 기준 수지가 맞도록 조정 */
    owner: { base: 3200, rank: [2600, 2000, 1500, 1000, 600, 350, 200, 100], trophy: { league: 2000, msi: 1500, worlds: 3500 }, leagueMul: { easy: 1, normal: 1.55, hard: 2.5, master: 3 } },
    goals: {
      bonusMul: 0.35, successRep: 5, failRep: -4,
      pools: {
        easy: [
          { id: 'e_rank6', type: 'rank', target: 6, label: '정규시즌 6위 이내', desc: '구단주: "중위권은 지켜 주세요."', bonusMul: 0.25 },
          { id: 'e_wins11', type: 'wins', target: 11, label: '정규시즌 11승 이상', desc: '구단주: "5할 승률은 기대합니다."', bonusMul: 0.25 },
          { id: 'e_playoff', type: 'playoff', target: 8, label: '플레이오프 진출', desc: '구단주: "포스트시즌 무대를 보고 싶습니다."', bonusMul: 0.3 },
          { id: 'e_msi', type: 'msi', target: 4, label: 'MSI 진출', desc: '구단주: "국제 무대에 우리 이름을 올립시다."', bonusMul: 0.45 },
          { id: 'e_funds', type: 'fundsUp', target: 1200, label: '구단 자금 +1,200 크레딧', desc: '구단주: "적자 없이 살림을 불려 주세요."', bonusMul: 0.3 },
          { id: 'e_grade', type: 'grade', grade: 'A', target: 1, label: 'A급 이상 선수 1명 보유', desc: '구단주: "간판 선수가 필요합니다."', bonusMul: 0.3 },
          { id: 'e_import', type: 'import', target: 1, label: '외국인 용병 1명 라인업 기용', desc: '구단주: "해외 선수의 경험을 들여오세요."', bonusMul: 0.3 }
        ],
        normal: [
          { id: 'n_rank5', type: 'rank', target: 5, label: '정규시즌 5위 이내', desc: '구단주: "상위권 경쟁에 끼어야 합니다."', bonusMul: 0.3 },
          { id: 'n_wins13', type: 'wins', target: 13, label: '정규시즌 13승 이상', desc: '구단주: "승률 5할 5푼을 요구합니다."', bonusMul: 0.3 },
          { id: 'n_msi', type: 'msi', target: 4, label: 'MSI 진출', desc: '구단주: "전반기를 4위 안에서 마치세요."', bonusMul: 0.5 },
          { id: 'n_po', type: 'playoff_win', target: 1, label: '플레이오프 우승', desc: '구단주: "우승컵이 필요합니다."', bonusMul: 0.8 },
          { id: 'n_funds', type: 'fundsUp', target: 2000, label: '구단 자금 +2,000 크레딧', desc: '구단주: "흑자 경영을 부탁합니다."', bonusMul: 0.3 },
          { id: 'n_grade', type: 'grade', grade: 'A', target: 2, label: 'A급 이상 선수 2명 보유', desc: '구단주: "투자 가치가 있는 선수단을 만드세요."', bonusMul: 0.4 },
          { id: 'n_home', type: 'homegrown', target: 3, label: '라인업 전원 현지 선수', desc: '구단주: "우리 지역 선수로 팬을 모읍시다."', bonusMul: 0.35 },
          { id: 'n_import', type: 'import', target: 1, label: '외국인 용병 1명 라인업 기용', desc: '구단주: "용병 카드를 써 보세요."', bonusMul: 0.3 }
        ],
        hard: [
          { id: 'h_rank4', type: 'rank', target: 4, label: '정규시즌 4위 이내', desc: '구단주: "플레이오프 상위 시드가 목표입니다."', bonusMul: 0.4 },
          { id: 'h_wins15', type: 'wins', target: 15, label: '정규시즌 15승 이상', desc: '구단주: "압도적인 승률을 보여 주세요."', bonusMul: 0.4 },
          { id: 'h_msi', type: 'msi', target: 4, label: 'MSI 진출', desc: '구단주: "국제 무대는 필수입니다."', bonusMul: 0.55 },
          { id: 'h_po', type: 'playoff_win', target: 1, label: '플레이오프 우승', desc: '구단주: "리그 정상에 서세요."', bonusMul: 0.8 },
          { id: 'h_worlds', type: 'worlds', target: 4, label: '월드 챔피언십 진출', desc: '구단주: "월드 무대에 우리 팀이 있어야 합니다."', bonusMul: 0.6 },
          { id: 'h_funds', type: 'fundsUp', target: 3000, label: '구단 자금 +3,000 크레딧', desc: '구단주: "수익 구조를 개선하세요."', bonusMul: 0.35 },
          { id: 'h_grade', type: 'grade', grade: 'S', target: 1, label: 'S급 선수 1명 보유', desc: '구단주: "리그를 대표할 슈퍼스타가 필요합니다."', bonusMul: 0.5 },
          { id: 'h_home', type: 'homegrown', target: 3, label: '라인업 전원 현지 선수', desc: '구단주: "토종 라인업으로 승부합시다."', bonusMul: 0.35 },
          { id: 'h_import', type: 'import', target: 1, label: '외국인 용병 1명 라인업 기용', desc: '구단주: "해외 스타를 영입해 보세요."', bonusMul: 0.3 }
        ],
        master: [
          { id: 'm_rank3', type: 'rank', target: 3, label: '정규시즌 3위 이내', desc: '구단주: "최상위권만 인정합니다."', bonusMul: 0.5 },
          { id: 'm_wins16', type: 'wins', target: 16, label: '정규시즌 16승 이상', desc: '구단주: "한국 리그의 자존심을 지키세요."', bonusMul: 0.45 },
          { id: 'm_msi', type: 'msi', target: 4, label: 'MSI 진출', desc: '구단주: "전반기 4위 안은 기본입니다."', bonusMul: 0.6 },
          { id: 'm_po', type: 'playoff_win', target: 1, label: '플레이오프 우승', desc: '구단주: "우승 외에는 의미가 없습니다."', bonusMul: 0.9 },
          { id: 'm_worlds', type: 'worlds', target: 4, label: '월드 챔피언십 진출', desc: '구단주: "세계 무대에서 증명하세요."', bonusMul: 0.7 },
          { id: 'm_funds', type: 'fundsUp', target: 4500, label: '구단 자금 +4,500 크레딧', desc: '구단주: "성적과 수익을 모두 잡으세요."', bonusMul: 0.4 },
          { id: 'm_grade', type: 'grade', grade: 'S', target: 2, label: 'S급 선수 2명 보유', desc: '구단주: "최고 선수들로 라인업을 채우세요."', bonusMul: 0.6 },
          { id: 'm_home', type: 'homegrown', target: 3, label: '라인업 전원 현지 선수', desc: '구단주: "한국인 라인업으로 팬심을 얻읍시다."', bonusMul: 0.4 }
        ]
      }
    }
  },

  challenges: [
    { id: 'first_win', icon: '🌱', name: '첫 승리', desc: '통산 1승 달성', type: 'wins', n: 1, reward: 300 },
    { id: 'wins_10', icon: '⚔️', name: '신예 감독', desc: '통산 10승 달성', type: 'wins', n: 10, reward: 500 },
    { id: 'wins_50', icon: '🛡️', name: '베테랑 감독', desc: '통산 50승 달성', type: 'wins', n: 50, reward: 1500 },
    { id: 'wins_150', icon: '🏛️', name: '명장', desc: '통산 150승 달성', type: 'wins', n: 150, reward: 4000 },
    { id: 'streak_5', icon: '🔥', name: '5연승', desc: '5연승 달성', type: 'streak', n: 5, reward: 800 },
    { id: 'streak_10', icon: '☄️', name: '10연승', desc: '10연승 달성', type: 'streak', n: 10, reward: 2500 },
    { id: 'league_1', icon: '🏆', name: '첫 리그 우승', desc: '리그 우승 1회', type: 'trophy', k: 'league', n: 1, reward: 1500 },
    { id: 'league_3', icon: '🏆', name: '리그 왕조', desc: '리그 우승 3회', type: 'trophy', k: 'league', n: 3, reward: 4000 },
    { id: 'msi_1', icon: '🥇', name: 'MSI 챔피언', desc: 'MSI 우승 1회', type: 'trophy', k: 'msi', n: 1, reward: 2500 },
    { id: 'worlds_1', icon: '👑', name: '월드 챔피언', desc: '월드 챔피언십 우승 1회', type: 'trophy', k: 'worlds', n: 1, reward: 6000 },
    { id: 'multi_league', icon: '🌍', name: '리그 정복자', desc: '서로 다른 2개 리그에서 우승', type: 'leagues', n: 2, reward: 5000 },
    { id: 'goals_3', icon: '🎯', name: '구단주의 신뢰', desc: '구단주 목표 3회 달성', type: 'goals', n: 3, reward: 2000 },
    { id: 'rare_1', icon: '💎', name: '전설의 재능', desc: '에이스 또는 완벽한 재능 선수 보유', type: 'rare', n: 1, reward: 3000 },
    { id: 'foreign_2', icon: '🌐', name: '글로벌 로스터', desc: '외국인 선수 2명 보유', type: 'foreign', n: 2, reward: 600 },
    { id: 'rich', icon: '💰', name: '부자 구단', desc: '구단 자금 25,000 크레딧 보유', type: 'funds', n: 25000, reward: 2500 },
    { id: 'seasons_5', icon: '📅', name: '장기 집권', desc: '시즌 5 도달', type: 'seasons', n: 5, reward: 1000 }
  ],

  ui: { teamColors: ['#5ee7ff', '#ff6ec7'], starCount: 90 },
  fighters: {}   // fighters.js 에서 채워집니다
};

/* 시간대 계획 항목은 운영 기조와 같은 선택지를 씁니다 */
CONFIG.tactics.team.filter(c => c.noLevel).forEach(c => {
  c.options = [{ id: 'follow', name: '기조 따름', desc: '이 시간대에도 운영 기조를 그대로 따릅니다.' }, ...CONFIG.tactics.team[0].options];
});
