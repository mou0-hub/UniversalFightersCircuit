/* news.js — 뉴스 / 커뮤니티 여론 / 감독 평판 / 선수 폼·멘탈 (league.js 에서 분리. league.js 뒤에 로드) */

/* ============================================================
   News — 롤갤/펨코 톤 커뮤니티 여론 + 감독 평판 + 선수 폼/멘탈
   G.news 최신순 저장 / G.rep = { v:0~100, peak, last }
   선수 pro.form(0~100), pro.mental 에 경기 후 평가가 반영됩니다.
   항목: { id, date, type, scope, headline, body[], comments[], repDelta?, ratings? }
   ============================================================ */
const News = (() => {
  const rnd = a => a[Math.floor(Math.random() * a.length)];
  const shuf = a => a.slice().sort(() => Math.random() - 0.5);
  const chance = p => Math.random() < p;
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const hasB = w => { const c = w.charCodeAt(w.length - 1); return (c >= 0xAC00 && c <= 0xD7A3 && (c - 0xAC00) % 28 !== 0) || (c >= 48 && c <= 57 && '013678'.includes(w[w.length - 1])); };
  const fill = (t, v) => t.replace(/\{(\w+)(?::([^}]+))?\}/g, (m, k, j) => {
    const w = String(v[k] != null ? v[k] : ''); if (!j) return w; const [a, b] = j.split('/');
    if (a === '으로') { const c = w.charCodeAt(w.length - 1), jong = c >= 0xAC00 && c <= 0xD7A3 ? (c - 0xAC00) % 28 : (c >= 48 && c <= 57 && '036'.includes(w[w.length - 1]) ? 1 : 0); return w + (jong && jong !== 8 ? '으로' : '로'); }
    return w + (hasB(w) ? a : b);
  });
  const F = id => (CONFIG.fighters[id] || {}).name || id;
  const ROLE = { warrior: '전사', mage: '마법', guardian: '수호', assassin: '암살', hunter: '사냥' };
  const roleOf = ids => ids.reduce((o, id) => { const r = (CONFIG.fighters[id] || {}).role || 'warrior'; o[r] = (o[r] || 0) + 1; return o; }, {});
  const rk = (G, id) => League.rankOf(G, id);
  const rec = (G, id) => { const t = League.team(G, id); return t ? `${t.w}승 ${t.d}무 ${t.l}패` : ''; };

  /* ----- 평판 ----- */
  function ensureRep(G) {
    if (!G.rep || typeof G.rep.v !== 'number') G.rep = { v: 50, peak: 50, last: 0 };
    return G.rep;
  }
  function repLabel(v) {
    if (v >= 85) return '리그 전설';
    if (v >= 70) return '인정받는 감독';
    if (v >= 55) return '무난한 평가';
    if (v >= 40) return '미묘한 시선';
    if (v >= 25) return '까이는 중';
    return '매국노 취급';
  }
  function shiftRep(G, delta, why) {
    const r = ensureRep(G);
    const before = r.v;
    r.v = clamp(Math.round(r.v + delta), 0, 100);
    r.peak = Math.max(r.peak || 0, r.v);
    r.last = r.v - before;
    r.why = why || '';
    return r.last;
  }

  /* ----- 선수 폼/멘탈 ----- */
  function ensureProMood(p) {
    if (p.form == null) p.form = 55 + Math.floor(Math.random() * 16);
    if (p.mental == null) p.mental = 70;
    return p;
  }
  function bumpPro(G, id, dForm, dMental) {
    const p = Pros.get(G, id); if (!p) return null;
    ensureProMood(p);
    p.form = clamp(Math.round(p.form + dForm), 0, 100);
    p.mental = clamp(Math.round(p.mental + dMental), 0, 100);
    return p;
  }

  /* ----- 커뮤니티 닉/톤 (롤갤·펨코 감성) ----- */
  const NA = ['롤', '갤', '조이', '노틸', '바드', '텔', '칼바람', '솔랭', '챌', '다이아', '플레', '언랭', '자랭', '듀오', '버스', '버스기사', '버스비', '원툴', '메가', '우주', '코스믹', '네온', '궤도', '성운', '혜성'];
  const NB = ['충', '전사', '유저', '장인', '교육생', '해설', '분석', '관종', '또라이', '뉴비', '고인물', '관측자', '직관러', '팬', '안티', '부캐', '본캐', '망나니', '아저씨', '누나'];
  const nick = () => {
    if (chance(0.2)) return 'ㅇㅇ';
    if (chance(0.12)) return '익명_' + Math.floor(Math.random() * 9000 + 1000);
    return rnd(NA) + rnd(NB) + (chance(0.4) ? String(Math.floor(Math.random() * 90 + 10)) : '');
  };
  const TONES = { hype: '🔥', salty: '💢', analyst: '🧠', meme: 'ㅋㅋ', rival: '🆚', toxic: '☠️', cope: '🥲' };

  const C = {
    hype: {
      win: [
        'ㅅㅂ {team} 오늘 뭐임 ㅋㅋㅋㅋ 개찢음',
        '{mvp} 버스 기사 인정 돈값함',
        '이게 진짜 {team}이지 ㅋㅋ 다음 경기도 이김 ㄱㄱ',
        '와 {score} 스코어 뭐냐 상대팀 멘탈 나갔겠다',
        '연승 각이다 ㄹㅇ 이 감독 뭔가 있네',
        '점령 운영 개깔끔했음 한타도 잘 싸워줌',
        '{mvp} 캐리 미쳤다 오늘 MVP 박제해라'
      ],
      lose: [
        '졌는데 내용 나쁘지 않았음 다음엔 이기자',
        '아쉽네 그래도 {mvp}는 밥값했다',
        '한 세트만 더 있었으면... 암튼 수고',
        '괜찮아 시즌 길다 한 경기로 뭐 안 바뀜'
      ],
      neutral: [
        '오늘 경기 기대된다 직관 각?',
        '{team} 폼 올라오는 중인데 이기면 분위기 타겠는데',
        '밴픽만 안 터지면 이길 듯'
      ]
    },
    salty: {
      win: [
        '이겼는데 내용 더러움 운빨 아님?',
        '상대가 더 못해준 거임 자만 금물',
        '다음 경기에 바로 질 각 보이는데 ㅋㅋ'
      ],
      lose: [
        '아 ㅋㅋ {team} 또 짐 이게 맞냐',
        '밴픽부터 이상했음 감독 뭐하냐',
        '{mvp} 오늘 완전 먹튀였는데 왜 기용함',
        '점령도 못 먹고 한타도 짐 뭐하는 거임',
        'ㅅㅂ 멘탈 나가네 이 팀 답이 없다',
        '감독 경질각 아님? 계속 이 짓거리면',
        '저 픽 조합 보고 이미 졌다고 생각함 ㄹㅇ'
      ],
      neutral: [
        '또 이상한 픽 나오는 거 아니냐 불안한데',
        '지난 경기 보고 기대 안 함',
        '이기면 다행 지면 원래 그런 팀'
      ]
    },
    analyst: {
      win: [
        '점령 우선순위가 잘 맞았음. {score}면 운영 우세 승리',
        '보스 타이밍 싸움에서 한 템포 빨랐던 게 승부처',
        '{mvp} 사이드 압박 → 본대 합류 동선이 좋았음',
        '시간대별 기조 전환이 교과서적이었음'
      ],
      lose: [
        '교전 패배 이후 재출격이 계속 밀려서 점령 회복이 안 됐음',
        '상대 조합 시너지 대응이 늦었음. 상성 문제 큼',
        '보스 포기 타이밍을 잘못 잡은 게 점수 차로 이어짐',
        '라인 분담이 흐트러지면서 코어를 계속 내줌'
      ],
      neutral: [
        '핵심은 코어 주변 시야 싸움이 될 듯',
        '선픽 이점을 어떻게 쓰느냐가 관건',
        '상대 선호 픽 보면 조합 대충 읽힘'
      ]
    },
    meme: {
      win: [
        '{mvp} 오늘 롤 잘하네? ㅋㅋㅋㅋ',
        '와 버스 타니까 편하다 기사님 감사합니다',
        '상대팀 채팅창 불타겠는데 ㅋㅋ',
        '이 경기는 레전드로 박제다 ㄹㅇ'
      ],
      lose: [
        '아 ㅋㅋ 또 짐 나 이 팀 응원하냐',
        '감독님 롤 해본 적 있으심? ㅋㅋ',
        '{mvp} 오늘 버스비 환불각',
        '점령 버튼 어디 있는지 모름? ㅋㅋㅋ'
      ],
      neutral: [
        '오늘도 한 방 있다 없냐 ㅋㅋ',
        '벤픽 보고 웃고 갑니다',
        '직관 갈까 말까 하다가 안 감 ㅋ'
      ]
    },
    rival: {
      win: [
        '{opp} 팬들 조용하네 ㅋㅋㅋ',
        '라이벌전 승리 개통쾌하다',
        '{opp} 저력 어디 갔냐'
      ],
      lose: [
        '{opp}한테 지니까 더 빡치네',
        '라이벌한테 지면서 자존심 팔아먹음',
        '{opp} 팬들 우짤 거리겠는데 ㅅㅂ'
      ],
      neutral: [
        '{opp}전이면 무조건 이겨야지',
        '라이벌전은 내용보다 결과가 중요함'
      ]
    },
    toxic: {
      win: [
        '이 감독 좀 치네? 당분간 까기 보류',
        '승리는 승리 인정함 근데 여전히 불안'
      ],
      lose: [
        '접어라 시발 이 팀',
        '선수들 손발 안 맞음 연습이나 더 해라',
        '팬 무시하냐 이런 경기력으로',
        '경질 청원 가고 싶음 ㄹㅇ'
      ],
      neutral: [
        '또 구라 기사 나오겠네',
        '기대하는 내가 병신임'
      ]
    },
    cope: {
      win: [
        '이기긴 했는데 상대가 약했음 자만 ㄴㄴ',
        '아직 시즌 초반이다 침착하자'
      ],
      lose: [
        '아직 시즌 많이 남음... 라고 씀',
        '패배로 배우는 거지 뭐 다음엔 나아질 듯',
        '점수 차는 안 컸음 희망 회로 가동'
      ],
      neutral: [
        '이기면 좋고 져도 경험이다...',
        '멘탈 관리가 제일 중요함'
      ]
    }
  };

  /* ----- 커뮤니티 여론 생성기 (조각 조합 — 매 호출마다 문장 재조합) ----- */
  const FRAG = {
    end: ['ㅋㅋ', 'ㅋㅋㅋ', 'ㄹㅇ', 'ㄷㄷ', 'ㅅㅂ', '헐', '와', '진짜', '개꿀', '레전드', '노답', '미쳤다', '실화냐', '인정', 'ㅋ', 'ㅎㅎ', 'ㅠㅠ', 'ㅇㅈ'],
    teamWin: ['오늘 미쳤다', '개찢었네', '폼 올랐다', '이거 우승각인데', '버스 기사 누구냐', '운영 깔끔했음', '한타 다 이김', '점령도 잘 먹고'],
    teamLose: ['또 짐', '이게 맞냐', '멘탈 나감', '내용이 없음', '점령 뭐함', '한타마다 짐', '감독 뭐하냐', '손발 안 맞음'],
    playerGood: ['캐리 인정', '돈값함', '개잘함', '오늘 MVP', '존재감 미쳤다', '한타 찢음'],
    playerBad: ['먹튀였음', '왜 기용함', '버스비 환불각', '동선 이상함', '한타 기여 0', '저거 벤 해야지'],
    coachGood: ['감독 좀 치네', '밴픽 괜찮았음', '전술 먹혔다', '교체 타이밍 굿'],
    coachBad: ['감독 경질각', '밴픽부터 이상', '전술 노답', '선수 탓만 하냐'],
    analystWin: ['점령 우선순위가 맞았음', '보스 타이밍 우세', '교전 선제공격이 먹힘', '라인 분담이 안정적이었음'],
    analystLose: ['재출격 타이밍이 밀림', '상성 대응 실패', '코어 방치가 패인', '한타 패배 후 복구 실패'],
    cope: ['시즌 아직 남음', '다음 경기에 보자', '한 경기로 판단 ㄴㄴ', '배우는 경기로 치자'],
    rivalWin: ['라이벌 팬 조용하네', '자존심 지킴', '더비 승리 통쾌'],
    rivalLose: ['라이벌한테 짐 ㅋㅋ', '더비에서 자존심 팔아먹음', '상대 팬 우짤 거리겠는데'],
    hypeLead: ['ㅅㅂ', '와', '오', '개', 'ㄹㅇ'],
    toxicLead: ['접어라', '진짜', '아', '뭐하냐', '시발']
  };
  function genComment(tone, mood, v) {
    const team = v.team || '우리 팀', opp = v.opp || '상대', mvp = v.mvp || '에이스', score = v.score || '';
    const e = () => rnd(FRAG.end);
    const pick2 = (a, b) => chance(0.5) ? rnd(a) : rnd(b);
    let s = '';
    if (tone === 'hype') {
      if (mood === 'win') s = chance(0.5)
        ? `${rnd(FRAG.hypeLead)} ${team} ${rnd(FRAG.teamWin)} ${e()}`
        : `${mvp} ${rnd(FRAG.playerGood)} ${e()}`;
      else if (mood === 'lose') s = `${team} 졌는데 ${rnd(FRAG.playerGood)}은 인정 ${e()}`;
      else s = `${team} 오늘 경기 기대된다 ${e()}`;
    } else if (tone === 'salty' || tone === 'toxic') {
      if (mood === 'lose') s = chance(0.45)
        ? `${rnd(FRAG.toxicLead)} ${team} ${rnd(FRAG.teamLose)} ${e()}`
        : chance(0.5) ? `${mvp} ${rnd(FRAG.playerBad)} ${e()}` : `${rnd(FRAG.coachBad)} ${e()}`;
      else if (mood === 'win') s = `이겼는데 ${rnd(['내용 더러움', '운빨이었음', '자만 금물'])} ${e()}`;
      else s = `${team} ${rnd(['불안한데', '또 구릴 듯', '기대 안 함'])} ${e()}`;
    } else if (tone === 'analyst') {
      if (mood === 'win') s = `${rnd(FRAG.analystWin)}.${score ? ' 스코어 ' + score + '.' : ''}`;
      else if (mood === 'lose') s = `${rnd(FRAG.analystLose)}.`;
      else s = `${rnd(['핵심은 코어 주변 싸움', '밴픽 이점이 관건', '점령 두 곳 싸움 예상'])}.`;
    } else if (tone === 'meme') {
      if (mood === 'win') s = chance(0.5) ? `${mvp} 오늘 롤 잘하네? ${e()}` : `버스 타니까 편하다 ${e()}`;
      else if (mood === 'lose') s = chance(0.5) ? `감독님 롤 해본 적 있으심? ${e()}` : `${mvp} 버스비 환불각 ${e()}`;
      else s = `${rnd(['밴픽 보고 웃고 갑니다', '직관 갈까 말까', '오늘도 한 방 있냐'])} ${e()}`;
    } else if (tone === 'rival') {
      if (mood === 'win') s = `${opp} ${rnd(FRAG.rivalWin)} ${e()}`;
      else if (mood === 'lose') s = `${opp} ${rnd(FRAG.rivalLose)} ${e()}`;
      else s = `${opp}전이면 무조건 이겨야지 ${e()}`;
    } else if (tone === 'cope') {
      s = `${rnd(FRAG.cope)} ${e()}`;
    } else {
      s = mood === 'win' ? `${team} ${rnd(FRAG.teamWin)} ${e()}` : `${team} ${rnd(FRAG.teamLose)} ${e()}`;
    }
    // 템플릿 풀과 30% 섞어 더 다양하게
    if (chance(0.3) && C[tone] && C[tone][mood] && C[tone][mood].length) {
      const templ = rnd(C[tone][mood]);
      if ([...templ.matchAll(/\{(\w+)/g)].every(m => v[m[1]] != null && v[m[1]] !== '')) s = fill(templ, v);
    }
    return s;
  }
  function comments(mood, v, n, tones) {
    const ts = tones || (mood === 'win'
      ? ['hype', 'hype', 'meme', 'analyst', 'rival', 'salty', 'toxic']
      : mood === 'lose'
        ? ['salty', 'toxic', 'meme', 'analyst', 'cope', 'rival', 'hype']
        : ['analyst', 'meme', 'hype', 'salty', 'rival', 'cope']);
    const out = [], used = new Set();
    for (let i = 0; i < n; i++) {
      const tone = ts[i % ts.length];
      let text = '', guard = 0;
      do {
        text = genComment(tone, mood, v);
        guard++;
      } while (used.has(text) && guard < 8);
      used.add(text);
      out.push({
        u: nick(),
        tone,
        t: text,
        like: Math.floor(Math.random() * (mood === 'win' && (tone === 'hype' || tone === 'meme') ? 80 : 40) + (tone === 'toxic' ? 5 : 10))
      });
    }
    return out.sort((a, b) => b.like - a.like);
  }

  function push(G, it) {
    G.news = G.news || [];
    it.id = it.id || ('n' + Date.now().toString(36) + Math.floor(Math.random() * 1000));
    if (it.dupKey && G.news.some(n => n.dupKey === it.dupKey)) return null;
    G.news.unshift(it); if (G.news.length > 160) G.news.length = 160;
    return it;
  }
  const mk = (G, date, type, scope, headline, body, cm, extra) =>
    push(G, { date: League.isoDate(date), type, scope, headline, body: (body || []).filter(Boolean), comments: cm || [], ...(extra || {}) });

  /* 내 팀 유닛 중 피해+치유가 가장 큰(bad면 가장 작은) 유닛 — res.units 기준 */
  const sideMvp = (res, M, bad) => {
    const us = ((res && res.units) || []).filter(u => u.team === M.pIdx); if (!us.length) return null;
    return us.reduce((a, u) => ((bad ? u.dmg + u.healed < a.dmg + a.healed : u.dmg + u.healed > a.dmg + a.healed) ? u : a));
  };

  /* ----- 경기 후 선수 평가 + 폼/멘탈 ----- */
  function rateLineup(G, info) {
    const { won, draw, res, M } = info;
    const line = (G.club && G.club.lineup) ? G.club.lineup.filter(Boolean) : [];
    if (!line.length) return { lines: [], ratings: [] };
    const bs = sideMvp(res, M, false), mvpId = bs ? bs.ch.id : (res && res.mvpFighter);      // 내 팀 기준 최다 기여 파이터
    const ratings = [];
    const lines = [];
    line.forEach((pid, i) => {
      const p = Pros.get(G, pid); if (!p) return;
      ensureProMood(p);
      // 기본 변동
      let dF = draw ? rnd([-2, 0, 1]) : won ? rnd([2, 4, 6, 8]) : rnd([-8, -6, -4, -2]);
      let dM = draw ? rnd([-1, 0, 1]) : won ? rnd([1, 2, 3]) : rnd([-5, -3, -2, -1]);
      let tag = '무난';
      // MVP 추정: 매치 파이터 매핑 불명확하면 슬롯0/랜덤 가산
      const isHero = (mvpId && p.favs && p.favs.includes(mvpId)) || (won && i === 0 && chance(0.45)) || chance(0.15);
      const isGoat = !won && !draw && (i === 0 ? chance(0.35) : chance(0.25));
      if (isHero && (won || draw)) {
        dF += rnd([4, 6, 8]); dM += rnd([2, 3, 4]); tag = '캐리';
      } else if (isGoat) {
        dF -= rnd([4, 6, 9]); dM -= rnd([3, 5, 7]); tag = '비난';
      } else if (won) tag = chance(0.3) ? '준수' : '무난';
      else if (!draw) tag = chance(0.35) ? '아쉬움' : '부진';

      // 트러블/슬랙 성향이면 멘탈 출렁
      if (p.trouble > 55 && !won) dM -= 2;
      if (p.slack > 55 && won) dF -= 1;
      if (p.mental < 40 && !won) dF -= 2;

      const before = { form: p.form, mental: p.mental };
      bumpPro(G, pid, dF, dM);
      const row = { id: pid, nick: p.nick, tag, dForm: p.form - before.form, dMental: p.mental - before.mental, form: p.form, mental: p.mental };
      ratings.push(row);

      if (tag === '캐리') lines.push(rnd([
        `▶ ${p.nick}: 오늘 경기 완전 캐리. 커뮤니티에서도 "버스 기사" 소리 나옴. 폼 ${before.form}→${p.form}`,
        `▶ ${p.nick}: 한타마다 존재감. 팬들 사이 재평가 중. 멘탈 ${before.mental}→${p.mental}`
      ]));
      else if (tag === '비난') lines.push(rnd([
        `▶ ${p.nick}: 오늘 욕 많이 먹음. "왜 기용하냐" 댓글 폭주. 폼 ${before.form}→${p.form}`,
        `▶ ${p.nick}: 결정적 실수 도마. 본인도 표정 안 좋았음. 멘탈 ${before.mental}→${p.mental}`
      ]));
      else if (tag === '부진') lines.push(`▶ ${p.nick}: 존재감 부족. 다음 경기 출전 여부 의견 갈림. 폼 ${before.form}→${p.form}`);
      else if (tag === '준수') lines.push(`▶ ${p.nick}: 실수 없이 역할 수행. 무난한 고평가. 폼 ${before.form}→${p.form}`);
      else lines.push(`▶ ${p.nick}: 평범. 큰 말은 없음. 폼 ${p.form} / 멘탈 ${p.mental}`);
    });
    return { lines, ratings };
  }

  function applyMatchRep(G, info) {
    const { won, draw, res, M } = info;
    const streak = G.streak || 0;
    let d = 0, why = '';
    if (draw) { d = chance(0.5) ? 0 : -1; why = '무승부'; }
    else if (won) {
      d = 3 + (streak >= 3 ? 2 : 0) + (streak >= 5 ? 2 : 0);
      if (M && M.kind === 'playoff') d += 2;
      if (M && (M.kind === 'msi' || M.kind === 'worlds')) d += 3;
      why = streak >= 3 ? `${streak}연승 중 승리` : '승리';
    } else {
      d = -4 - (streak === 0 && G.totals && G.totals.games > 3 ? 1 : 0);
      if (M && M.kind === 'playoff') d -= 2;
      if (M && (M.kind === 'msi' || M.kind === 'worlds')) d -= 3;
      why = '패배';
    }
    // 여론은 평판이 낮을수록 패배에 더 가혹, 높을수록 승리에 가산
    const r = ensureRep(G);
    if (!won && !draw && r.v < 35) d -= 1;
    if (won && r.v > 70) d += 1;
    return shiftRep(G, d, why);
  }

  /* ----- 경기 전 ----- */
  function preview(G, M, date) {
    const me = G.teamName, opp = M.teams[1 - M.pIdx].name, oid = M.teams[1 - M.pIdx].id, label = M.label;
    const my = rk(G, 'player'), orank = rk(G, oid), st = G.streak, fav = (League.team(G, oid).fav || []).slice(0, 2).map(F);
    const rep = ensureRep(G);
    const v = { team: me, opp, label, streak: st, mvp: '에이스', score: '' };
    let head;
    if (st >= 3) head = rnd(['{streak}연승 {team}, 오늘도 이기면 여론 폭발각', '연승 중인데 {opp} 만나면 긴장된다는데 ㄱㄱ?', '{team} 상승세 vs {opp} — 커뮤니티 시선 집중']);
    else if (rep.v < 35) head = rnd(['여론 최악인 {team}, {opp}전에서 반등할까', '감독 까는 중인데 오늘 지면 진짜 끝임']);
    else if (orank && my && orank < my) head = rnd(['상위권 {opp} 상대로 반란 가능하냐', '{label}: 도전자 {team} 인식전']);
    else head = rnd(['{team} vs {opp} 프리뷰 — 점령 싸움 예상', '오늘 {label}, 커뮤니티 반응은 미지근']);
    const body = [
      fill('오늘 {team}과 {opp}의 {label}. 점령전 메타에서 운영 한 끗이 갈린다.', v),
      my ? fill('{team} 현재 {r}위({rec}). 감독 평판 {rep}({lab}).', { team: me, r: my, rec: rec(G, 'player'), rep: rep.v, lab: repLabel(rep.v) }) : '',
      orank ? `${opp}${hasB(opp) ? '은' : '는'} ${orank}위(${rec(G, oid)}).` : '',
      fav.length ? `상대 최근 픽 경향: ${fav.join('·')}. 밴 우선순위로 꼽힌다.` : '',
      st >= 2 ? `${st}연승 중이라 팬층은 들뜬 분위기.` : (st === 0 && G.totals && G.totals.games ? '직전 패배 때문에 커뮤니티 칼침 예고.' : '개막 분위기. 기대 반 걱정 반.')
    ];
    return mk(G, date, 'preview', M.kind === 'league' ? 'me' : 'intl', fill(head, v), body, comments('neutral', v, 6), { dupKey: 'pv' + M.label + opp + League.isoDate(date) });
  }

  /* ----- 밴픽 후 ----- */
  function draft(G, M, date) {
    const me = G.teamName, oi = M.teams[1 - M.pIdx].name, mine = M.picks[M.pIdx], theirs = M.picks[1 - M.pIdx];
    const rc = roleOf(mine), top = Object.keys(rc).sort((a, b) => rc[b] - rc[a])[0];
    const comp = rc[top] >= 2 ? `${ROLE[top] || top} 편중 조합` : '밸런스 조합';
    const bans = [...(M.bans[0] || []), ...(M.bans[1] || [])].map(F);
    const v = { team: me, opp: oi, mvp: F(mine[0]), score: '' };
    const head = rnd([
      `밴픽 분석: ${me} ${comp} 꺼냄`,
      `${mine.map(F).join('·')} 픽 — 커뮤니티 반응 분분`,
      bans.length ? `${bans[0]} 밴 이후 판 읽기` : `밴픽 종료, ${me} 선택 공개`
    ]);
    const body = [
      `${me} 픽: ${mine.map(F).join(', ')}. ${comp}으로 보는 쪽과 "또 저거?" 하는 쪽이 갈림.`,
      `${oi} 픽: ${theirs.map(F).join(', ')}.`,
      bans.length ? `밴 카드: ${bans.join(', ')}.` : '',
      chance(0.5) ? rnd(['선픽 이점을 살렸다는 평.', '후픽 운영으로 맞춰 간다는 해석.', '조합 시너지 미지수라는 분석 댓글 다수.']) : ''
    ];
    return mk(G, date, 'draft', 'me', head, body, comments('neutral', v, 5, ['analyst', 'meme', 'salty', 'hype', 'toxic']), { dupKey: 'dr' + M.label + League.isoDate(date) });
  }

  /* ----- 경기 결과 ----- */
  function result(G, info, date) {
    const { won, draw, res, M } = info;
    const me = G.teamName, opp = M.teams[1 - M.pIdx].name;
    const score = res && res.score ? `${res.score[M.pIdx]}:${res.score[1 - M.pIdx]}` : (res && res.scoreText) || (won ? '승' : draw ? '무' : '패');      // 내 팀 점수가 앞
    const su = sideMvp(res, M, !won && !draw);                  // 승/무: 내 팀 최다 기여 · 패배: 내 팀 최저 기여(기사에서 지적 대상)
    const mvp = su ? (nickOf(G, M, su) || su.ch.name) : ((res && res.mvpName) || (res && res.mvpFighter ? F(res.mvpFighter) : '에이스'));
    const v = { team: me, opp, mvp, score };
    const mood = draw ? 'neutral' : won ? 'win' : 'lose';
    const repDelta = applyMatchRep(G, info);
    const rep = ensureRep(G);
    const rated = rateLineup(G, info);
    /* 경기 결과로 폼/멘탈이 변동된 뒤, 높은 확률로 기본값(55/70)으로 복구. 복구 안 되면 다음 경기 AI에 영향 */
    if (G.club && G.club.lineup) {
      G.club.lineup.filter(Boolean).forEach(pid => {
        const p = Pros.get(G, pid); if (!p) return;
        ensureProMood(p);
        if (Math.random() < 0.75) {          // 약 75% 확률로 원상복구
          p.form = 55;
          p.mental = 70;
        }
      });
    }

    let head;
    if (draw) head = rnd([`{team} vs {opp}, 무승부 — 여론도 애매`, `점수 나눠 가짐 {score}. 양쪽 팬 조용`]);
    else if (won) head = rnd([
      `{team}, {opp} 잡고 승리 ㅅㅅ — {score}`,
      `{mvp} 캐리로 {team} 승! 커뮤니티 분위기 좋음`,
      G.streak >= 3 ? `{team} {streak}연승 질주 ㅋㅋㅋ`.replace('{streak}', G.streak) : `{team} 승리. 감독 평판 ${rep.v}로 ${repDelta >= 0 ? '상승' : '하락'}`
    ]);
    else head = rnd([
      `{team}, {opp}에 패배… 여론 싸늘`,
      `또 짐 ㅋㅋ {score} — 감독 무능 논란`,
      `{opp}에 덜미. 선수 개개인 평가 갈림`
    ]);

    const body = [
      fill(draw ? '{team}과 {opp}가 {score}로 비겼다.' : won ? '{team:은/는} {opp}를 꺾고 승리했다. 스코어 {score}.' : '{team:은/는} {opp}에 패했다. 스코어 {score}.', v),
      won ? fill('{mvp} 활약이 돋보였다는 반응이 많다.' , v) : (!draw ? fill('패인으로 {mvp} 쪽 동선/교전 선택이 도마에 올랐다.', v) : '결정타가 없던 경기라는 평.'),
      `감독 평판 ${rep.v} (${repLabel(rep.v)}) · 변동 ${repDelta >= 0 ? '+' : ''}${repDelta} — ${rep.why || ''}`,
      '【선수 평가】',
      ...rated.lines
    ];

    const tones = mood === 'win'
      ? ['hype', 'hype', 'meme', 'analyst', 'rival', 'salty', 'toxic', 'cope']
      : mood === 'lose'
        ? ['salty', 'toxic', 'toxic', 'meme', 'analyst', 'cope', 'rival', 'hype']
        : ['analyst', 'meme', 'cope', 'salty', 'hype'];

    return mk(G, date, 'result', M.kind === 'league' ? 'me' : 'intl', fill(head, v), body, comments(mood, v, 8, tones), {
      hot: !draw,
      repDelta,
      ratings: rated.ratings,
      dupKey: 'rs' + M.label + opp + League.isoDate(date)
    });
  }

  /* ----- 경기 후 전투 분석 칼럼 (res.rec 기반 · 내 경기 전용) ----- */
  const AN = () => CONFIG.news.analysis;
  const tps = () => 1000 / CONFIG.battle.tickMs;
  const fmtT = t => { const s = Math.round(t / tps()); return s >= 60 ? `${Math.floor(s / 60)}분 ${s % 60}초` : `${s}초`; };
  const S = (pool, v) => fill(rnd(pool), v).replace(/\s{2,}/g, ' ').trim();
  const num = n => Math.round(n).toLocaleString();
  const HOW = { kill: '처치', ace: '전멸 보너스', boss: '보스 처치' };
  const bossName = b => (CONFIG.bossDefs && CONFIG.bossDefs[b.def] && CONFIG.bossDefs[b.def].name) || (b.kind === 'mid' ? '중앙 보스' : '후반 보스');
  const optName = (list, c, id) => { const k = list.find(x => x.id === c), o = k && k.options.find(x => x.id === id); return o ? o.name : id; };
  const tacVal = (list, raw, c) => { const k = list.find(x => x.id === c), v = raw && raw[c]; return v && k && k.options.some(o => o.id === v[0]) ? v[0] : (k ? k.neutral : ''); };

  function nickOf(G, M, u) {
    if (u.nick) return u.nick;
    if (u.team !== M.pIdx) return '';
    const line = (G.club && G.club.lineup ? G.club.lineup : []).filter(Boolean), p = line[u.slot] && Pros.get(G, line[u.slot]);
    return (p && p.nick) || '';
  }
  const whoOf = (G, M, u) => { const nk = nickOf(G, M, u); return { who: nk || u.ch.name, chv: nk ? fill('{c:으로/로}', { c: u.ch.name }) : '', nick: nk, ch: u.ch.name }; };

  const P = {
    openK: ['경기는 {t}, {kil:이/가} {vic:을/를} 먼저 쓰러뜨리며 열렸다.', '첫 처치는 {side}의 몫이었다. {t}, {kil:이/가} {vic:을/를} 잡아냈다.', '선취점은 {t}에 나왔다. {kil:이/가} {vic:을/를} 끊어 {side:이/가} 먼저 웃었다.'],
    openKV: ['경기는 {t}, {kil:이/가} {via:으로/로} {vic:을/를} 먼저 쓰러뜨리며 열렸다.', '첫 처치는 {side}의 몫. {t}, {kil:이/가} {via:으로/로} {vic:을/를} 정리했다.'],
    sudKV: ['승부는 서든데스에서 갈렸다. {t}에 {kil:이/가} {via:으로/로} {vic:을/를} 잡아낸 한 번의 교전이 전부였다.'],
    openV: ['{t}, {vic:이/가} 가장 먼저 쓰러지며 첫 점수가 났다.', '초반 첫 사망은 {t}에 나온 {vic}였다.'],
    openN: ['{me:과/와} {opp}의 경기는 초반 탐색전이 길었다.', '초반에는 서로 눈치만 보며 처치 없이 시간이 흘렀다.'],
    comeback: ['한때 {def}점까지 끌려갔던 {side:이/가} {t}, {how:으로/로} 균형을 뒤집었다.', '{side:은/는} {def}점 열세를 안고도 {t} {how:으로/로} 역전에 성공했다.', '승부는 {t}에 뒤집혔다. {def}점 뒤지던 {side:이/가} {how:으로/로} 앞서 나갔다.'],
    closeW: ['{t}, {how:으로/로} 앞서 나간 {side:이/가} 그 리드를 끝까지 지켜냈다.', '접전 끝에 {t} {how:으로/로} 점수를 벌린 {side:이/가} 흐름을 가져갔다.'],
    lostLead: ['{me:이/가} {lead}점까지 앞서 갔지만 {t}, {opp}의 {how:으로/로} 흐름이 넘어갔다.', '{lead}점 리드는 {t}를 기점으로 사라졌다. {opp:이/가} {how:으로/로} 단숨에 따라붙었다.', '앞서던 {me:은/는} {t}에 {how:으로/로} 리드를 내줬고, 끝내 되찾지 못했다.'],
    closeL: ['{t}, {opp:이/가} {how:으로/로} 앞서 나가며 접전의 균형이 기울었다.', '접전은 {t}에 {opp} 쪽으로 넘어갔다. {how:이/가} 결정타였다.'],
    bossW: ['{t}, {boss:을/를} 쓰러뜨린 {side:이/가} {pts}점을 한꺼번에 챙기며 판을 가져갔다.', '{boss} 처치({side}, {t})가 승부의 분수령이었다. 한 번에 {pts}점이 움직였다.'],
    bossL: ['{t}, {side:이/가} {boss:을/를} 가져가 {pts}점을 챙겼지만 흐름 전체를 바꾸지는 못했다.', '{boss:은/는} {side:이/가} 처치해 {pts}점을 얻었다. 다만 그 점수만으로는 격차를 메우지 못했다.'],
    fight: ['{from}~{to} 사이 처치 {n}회가 몰린 한타에서 {side:이/가} {ab:으로/로} 압도했고, 이 구간이 점수 차를 만들었다.', '{from}부터 {to}까지의 교전은 {side}의 완승({a}:{b})이었다. 한타 한 번이 경기 분위기를 바꿨다.'],
    wire: ['{side:은/는} 한 번도 리드를 내주지 않고 경기를 이끌었다.', '경기 내내 점수판은 {side} 쪽에서 움직였다. 역전 한 번 없는 안정적인 흐름이었다.'],
    sudKill: ['정규 시간에 점수가 같아 서든데스까지 갔다. {t}, {kil:이/가} {vic:을/를} 쓰러뜨리며 승부를 끝냈다.', '승부는 서든데스에서 갈렸다. {t}에 {kil:이/가} {vic:을/를} 잡아낸 한 번의 교전이 전부였다.'],
    sudDeath: ['정규 시간에 점수가 같아 서든데스로 넘어갔고, {t}에 나온 첫 사망이 승패를 갈랐다.'],
    sudHp: ['서든데스에서도 처치가 나오지 않아 남은 체력 {a}% 대 {b}%로 승패가 갈렸다.', '서든데스 제한 시간까지 결판이 나지 않았다. 잔여 체력 {a}% 대 {b}%가 결과를 정했다.'],
    sudDraw: ['서든데스까지 갔지만 끝내 승부를 가르지 못했다.'],
    endW: ['최종 점수 {sc}, 보스 처치는 {bb}. {me:은/는} 필요한 순간에 점수를 챙겼다.', '{sc:으로/로} 끝난 경기. 보스 처치 {bb:이/가} 숫자로 흐름을 요약한다.'],
    endL: ['최종 점수 {sc}, 보스 처치는 {bb}. 승부처에서의 손실을 끝내 메우지 못했다.', '{sc:으로/로} 마무리. 보스 처치 {bb:이/가} 말해 주듯 중요한 순간마다 한발 늦었다.'],
    endD: ['{sc:으로/로} 승부를 가르지 못했다. 보스 처치는 {bb}.', '{sc:으로/로} 비긴 경기. 어느 쪽도 결정타를 만들지 못했다.'],

    starD: ['수훈 선수로는 {who:을/를} 꼽을 수 있다. {chv} 피해 {dmg}, 처치 {k}회, 데스 {d}회로 팀 기여도 {pct}%를 책임졌다.', '{who:은/는} {chv} 피해 {dmg}에 처치 {k}회를 쌓으며 경기를 끌고 갔다. 데스는 {d}회, 기여도는 {pct}%.', '가장 눈에 띈 쪽은 {who}였다. {chv} 피해 {dmg} · 처치 {k} · 데스 {d}로 팀 화력의 중심이었다.'],
    starH: ['{who:은/는} {chv} 치유 {heal}로 라인을 떠받친 숨은 수훈 선수였다. 피해도 {dmg:을/를} 보탰고 데스는 {d}회.', '수훈 선수는 {who}. {chv} 치유 {heal}에 피해 {dmg}까지 더하며 팀 기여도 {pct}%를 기록했다.'],
    badD: ['반면 {who:은/는} 데스 {d}회에 피해 {dmg:으로/로} 존재감이 옅어 재출격 공백이 아쉬웠다.', '부진 쪽에서는 {who:이/가} 먼저 거론된다. 데스 {d}회, 팀 기여도 {pct}%에 그쳤다.', '{who:이/가} 교전마다 일찍 쓰러지며 데스 {d}회를 쌓은 점이 뼈아팠다.'],
    badS: ['{who:은/는} {chv} 피해 {dmg}에 그치며 팀 기여도가 {pct}%에 머물렀다.', '{who}의 존재감이 옅었던 점이 아쉽다. 기여도 {pct}%, 처치 {k}회.'],
    noBad: ['눈에 띄는 부진은 없었다. 선수 전원이 제 몫은 해냈다.', '뚜렷하게 흔들린 선수는 없었다는 평가.'],
    noBadL: ['개인 부진보다는 팀 단위의 연결이 아쉬웠다는 평가.', '선수 개개인의 부진보다 합이 맞지 않은 쪽이 컸다.'],
    tank: ['{who:은/는} {chv} 팀 전체 피해의 {pct}%({taken})를 받아내며 전열을 지켰다.', '전열의 {who:이/가} 받은 피해 {taken}으로 아군의 부담을 덜었다. 데스는 {d}회뿐이었다.'],
    oppStar: ['상대 {who:이/가} {chv} 피해 {dmg}에 처치 {k}회로 판을 지배한 점도 컸다.', '{opp}의 {who:을/를} 끝내 막지 못했다. 피해 {dmg}, 처치 {k}회.'],
    ult0: ['이날 우리 팀은 궁극기를 한 번도 쓰지 못했다.', '궁극기는 끝내 나가지 않았다. 자원 관리와 타이밍 모두 숙제로 남았다.'],
    ultLess: ['궁극기 사용은 {a}회 대 {b}회로 상대가 앞섰다.'],
    ultMore: ['궁극기 사용은 {a}회 대 {b}회로 우리 쪽이 더 적극적이었다.'],

    tacG: ['{who}에게 건 \'{opt}\'({cat}) 지시가 통했다. 처치 {k}회, 데스 {d}회.', '\'{opt}\'({cat}) 지시를 받은 {who:이/가} 처치 {k}회·데스 {d}회로 역할을 해냈다.'],
    tacB: ['{who}에게 준 \'{opt}\'({cat}) 지시는 처치 {k}회·데스 {d}회에 그치며 독이 됐다.', '\'{opt}\'({cat}) 지시를 받은 {who:이/가} 기대에 못 미쳤다. 처치 {k}회, 데스 {d}회.'],
    tacNone: ['개인 지시에서는 눈에 띄는 변수가 없었다. 세부 지시보다 팀 기조가 결과를 좌우했다.'],
    ctrPW: ['밴픽에서는 {gA:이/가} {gB:을/를} 견제하는 구도로 상성 우위를 잡았고, 그 우위가 결과로 이어졌다.', '조합 상성은 우리 쪽이 앞섰다. 특히 {gA:과/와} {gB}의 맞대결 구도가 유리했다.'],
    ctrPL: ['상성 자체는 {gA:이/가} {gB:을/를} 누르는 우리 쪽 우위였지만, 그 이점을 교전에서 살리지 못했다.', '밴픽 단계의 상성 우위({gA} 대 {gB})가 실제 전투로 이어지지 않은 점이 아쉽다.'],
    ctrNW: ['밴픽 상성은 {opp} 쪽이 유리했다({bA:이/가} {mA:을/를} 압박하는 구도). 그럼에도 운영으로 열세를 뒤집었다.', '{bA:이/가} {mA:을/를} 누르는 불리한 상성이었지만 팀 운영으로 극복한 점이 돋보인다.'],
    ctrNL: ['밴픽 상성이 발목을 잡았다. {bA:이/가} {mA:을/를} 압박하는 구도에서 끝내 풀어내지 못했다.', '{opp:이/가} 상성에서 앞선 판이었다. 특히 {bA}의 {mA} 견제가 컸다.'],
    ctrE: ['조합 상성은 팽팽해 밴픽보다 운영과 교전 선택이 승부를 갈랐다.', '밴픽 상성에서는 뚜렷한 우열이 없었다.'],
    ban: ['우리의 밴 카드는 {ban:이었다/였다}.', '{ban:을/를} 밴해 상대의 선택지를 줄였다.']
  };
  const STANCE = {
    slay: { g: ['\'{nm}\' 기조가 맞아떨어졌다. 처치 {kk:으로/로} 앞서며 점수와 부활 공백을 함께 만들었다.'], b: ['\'{nm}\' 기조를 택했지만 처치가 {kk:으로/로} 밀렸다. 보스 대응까지 늦어져 기조의 약점이 그대로 드러났다.'] },
    objective: { g: ['\'{nm}\' 기조대로 보스 처치 {bb:으로/로} 판의 무게중심을 가져왔다.'], b: ['\'{nm}\' 기조였지만 보스 처치가 {bb:으로/로} 따라주지 않았다. 중앙 싸움의 손실이 컸다.'] },
    capture: { g: ['\'{nm}\' 기조로 힐 루트를 장악해 남은 체력 {hpA}% 대 {hpB}%의 우위를 만들었다.'], b: ['\'{nm}\' 기조에도 남은 체력이 {hpA}% 대 {hpB}%로 밀려 회복 싸움에서 앞서지 못했다.'] },
    defend: { g: ['\'{nm}\' 기조로 목숨을 아끼며 버틴 게 통했다. 팀 데스는 {dA}회로 재출격 공백을 줄였다.'], b: ['\'{nm}\' 기조가 지나치게 소극적이었다. 물러서는 사이 {opp}에 주도권을 내줬다.'] },
    balanced: { g: ['\'{nm}\' 기조는 무난했다. 처치 {kk}, 보스 {bb:으로/로} 어느 한쪽에 치우치지 않고 이겼다.'], b: ['\'{nm}\' 기조로 맞섰지만 처치 {kk}, 보스 {bb:으로/로} 뚜렷한 강점을 만들지 못했다.'] }
  };
  const BOSSP = {
    contest: { g: ['\'{nm}\' 방침대로 보스를 적극 공략해 {bb:으로/로} 앞섰다.'], b: ['\'{nm}\' 방침으로 보스에 달려들었지만 처치 {bb:으로/로} 이득을 보지 못했다.'] },
    steal: { g: ['\'{nm}\' 방침이 먹혀 보스 막타를 가져오며 {bA}회 점수를 챙겼다.'], b: ['\'{nm}\' 방침으로 기회를 노렸지만 막타를 한 번도 가져오지 못했다.'] },
    yield: { g: ['\'{nm}\' 방침으로 보스를 넘기는 대신 처치 {kk:으로/로} 점수를 만회했다.'], b: ['\'{nm}\' 방침으로 보스를 포기했지만 처치 {kk:으로/로}는 그 손실을 메우지 못했다.'] }
  };
  const SCOREP = {
    turtle: { g: ['앞선 뒤 \'{nm}\' 지침이 제때 작동해 리드를 지켰다.'], b: ['\'{nm}\' 지침을 걸었지만 앞선 점수를 끝까지 지키지는 못했다.'] },
    press: { g: ['앞선 뒤 \'{nm}\' 지침으로 끝장을 보며 격차를 벌렸다.'], b: ['\'{nm}\' 지침으로 몰아붙였지만 마무리가 이어지지 않았다.'] },
    gamble: { g: ['뒤처진 상황에서 \'{nm}\' 지침이 통해 한 방을 만들었다.'], b: ['뒤처진 상황의 \'{nm}\' 지침은 불발로 끝났다.'] },
    steady: { g: ['뒤처진 상황에서도 \'{nm}\' 지침으로 차분히 따라붙었다.'], b: ['\'{nm}\' 지침으로 소모전을 걸었지만 점수 차를 좁히지 못했다.'] }
  };
  const HEAD = {
    sudden: ['[전투 분석] 서든데스까지 간 {me}-{opp}전, 마지막 한 점의 무게', '[전투 분석] 정규 시간으로 끝나지 않은 승부 — {me} 대 {opp} 복기'],
    comeback: ['[전투 분석] {me}, {t} 역전극의 설계도', '[전투 분석] 뒤집은 한 수 — {me}의 {opp}전 복기'],
    lostlead: ['[전투 분석] 잡았던 리드는 어디서 사라졌나 — {me} 대 {opp}', '[전투 분석] {opp}전 패인, 리드를 지키지 못한 {t} 이후'],
    boss: ['[전투 분석] 보스가 가른 승부 — {me} 대 {opp}', '[전투 분석] {boss} 한 번에 갈린 {me}-{opp}전'],
    fight: ['[전투 분석] 한타 한 번에 갈린 {me}-{opp}전', '[전투 분석] {t}의 교전이 만든 점수 차'],
    wire: ['[전투 분석] 흔들림 없이 이끈 {me}, {opp}전 숫자로 복기', '[전투 분석] 리드를 한 번도 내주지 않은 {me}의 {opp}전'],
    close: ['[전투 분석] 접전 끝 {me} 대 {opp}, 승부를 가른 {t}의 장면', '[전투 분석] {t}에 기운 접전 — {me}-{opp}전 복기'],
    win: ['[전투 분석] {me}의 {opp}전, 숫자로 읽는 승인'],
    lose: ['[전투 분석] {opp}전 패인 해부 — {me}에 무엇이 부족했나'],
    draw: ['[전투 분석] 승부를 가르지 못한 {me}-{opp}전 복기']
  };

  function wantAnalysis(res, M) {
    const A = AN(); if (!A || A.mode === 'off') return false;
    if (A.mode === 'all') return true;
    if (M.kind !== 'league' || res.sudden || Math.abs(res.score[0] - res.score[1]) >= A.bigDiff) return true;
    return A.mode === 'chance' && chance(A.chance);
  }

  function digest(G, info) {
    const { res, M } = info, R = res.rec, my = M.pIdx, op = 1 - my, A = AN();
    const us = res.units, mine = us.filter(u => u.team === my), theirs = us.filter(u => u.team === op), byId = {};
    us.forEach(u => { byId[u.id] = u; });
    const sum = (l, k) => l.reduce((s, u) => s + (u[k] || 0), 0), con = u => u.dmg + u.healed;
    const lead = [0, 0], s = [0, 0];
    R.pts.forEach(e => { s[e.team] += e.pts; const d = s[0] - s[1]; lead[0] = Math.max(lead[0], d); lead[1] = Math.max(lead[1], -d); });
    let fight = null; const ks = R.kills, W = Math.round(A.fightSec * tps());
    for (let i = 0; i < ks.length; i++) {
      let j = i; while (j + 1 < ks.length && ks[j + 1].t - ks[i].t <= W) j++;
      const n = j - i + 1; if (n < A.fightMin) continue;
      const c = [0, 0]; for (let q = i; q <= j; q++) if (ks[q].kt === 0 || ks[q].kt === 1) c[ks[q].kt]++;
      const gap = Math.abs(c[0] - c[1]);
      if (!fight || n > fight.n || (n === fight.n && gap > fight.gap)) fight = { from: ks[i].t, to: ks[j].t, n, c, gap, win: c[0] === c[1] ? -1 : (c[0] > c[1] ? 0 : 1) };
    }
    const D = {
      G, M, res, R, my, op, me: G.teamName, opp: M.teams[op].name, mine, theirs, byId, con, lead, fight,
      pv: u => whoOf(G, M, u), nm: u => whoOf(G, M, u).who,
      mineTot: sum(mine, 'dmg') + sum(mine, 'healed'), mineTaken: sum(mine, 'taken'),
      k: [sum(mine, 'kills'), sum(theirs, 'kills')], d: [sum(mine, 'deaths'), sum(theirs, 'deaths')], u: [sum(mine, 'ults'), sum(theirs, 'ults')],
      b: [res.bossKills[my], res.bossKills[op]], hp: [Math.round(res.hp[my] * 100), Math.round(res.hp[op] * 100)], sc: [res.score[my], res.score[op]]
    };
    const lf = R.flips[R.flips.length - 1];
    D.lostLead = !!(lf && res.winner === op && lf.team === op && lead[my] >= A.leadGap);
    return D;
  }

  /* 승부처 후보 → 가중치 상위 2개를 시간순으로 */
  function moments(D) {
    const { res, R, my, op, lead } = D, A = AN(), out = [], wt = res.winner, side = t => (t === my ? D.me : D.opp), unit = id => (id ? D.byId[id] : null);
    if (res.sudden) {
      const sd = R.kills.find(k => k.t >= R.suddenAt), k = sd && unit(sd.k), vi = sd && unit(sd.v);
      let txt;
      if (wt === -1) txt = S(P.sudDraw, {});
      else if (res.suddenLoser != null && sd) txt = k && vi ? S(sd.via && sd.via !== '기본 공격' ? P.sudKV : P.sudKill, { t: fmtT(sd.t), kil: D.nm(k), vic: D.nm(vi), via: sd.via }) : S(P.sudDeath, { t: fmtT(sd.t) });
      else txt = S(P.sudHp, { a: D.hp[0], b: D.hp[1] });
      out.push({ kind: 'sudden', w: 6, t: sd ? sd.t : R.suddenAt, txt, hv: {} });
    }
    const lf = R.flips[R.flips.length - 1];
    if (lf && wt >= 0 && lf.team === wt) {
      const behind = lead[1 - wt], big = behind >= A.leadGap, how = HOW[lf.why] || '득점', t = fmtT(lf.t);
      if (wt === my) out.push({ kind: big ? 'comeback' : 'close', w: big ? 5 : 3, t: lf.t, txt: S(big ? P.comeback : P.closeW, { side: D.me, def: behind, t, how }), hv: { t } });
      else out.push({ kind: big ? 'lostlead' : 'close', w: big ? 5 : 3, t: lf.t, txt: S(big ? P.lostLead : P.closeL, { me: D.me, opp: D.opp, lead: behind, t, how }), hv: { t } });
    }
    const bd = R.boss.filter(b => b.ph === 'down').sort((a, b) => b.pts - a.pts || a.t - b.t)[0];
    if (bd) { const t = fmtT(bd.t), boss = bossName(bd); out.push({ kind: 'boss', w: bd.team === wt ? 4 : 2.5, t: bd.t, txt: S(bd.team === wt ? P.bossW : P.bossL, { side: side(bd.team), t, boss, pts: bd.pts }), hv: { t, boss } }); }
    const f = D.fight;
    if (f && f.gap >= 1) out.push({ kind: 'fight', w: 3.5, t: f.from, txt: S(P.fight, { side: side(f.win), from: fmtT(f.from), to: fmtT(f.to), n: f.n, a: f.c[f.win], b: f.c[1 - f.win], ab: `${f.c[f.win]}:${f.c[1 - f.win]}` }), hv: { t: fmtT(f.from) } });
    if (!R.flips.length && wt >= 0 && Math.abs(res.score[0] - res.score[1]) >= 2) out.push({ kind: 'wire', w: 2, t: R.first ? R.first.t : 0, txt: S(P.wire, { side: side(wt) }), hv: {} });
    out.sort((a, b) => b.w - a.w || Math.random() - 0.5);
    const top = out[0] || null;
    return { top, list: out.slice(0, 2).sort((a, b) => a.t - b.t) };
  }

  function pTurning(D) {
    const { R, res, my } = D, parts = [], f = R.first, won = res.winner === my, draw = res.winner === -1;
    if (f) {
      const k = f.k && D.byId[f.k], vi = D.byId[f.v];
      parts.push(k && vi ? S(f.via && f.via !== '기본 공격' ? P.openKV : P.openK, { side: f.kt === my ? D.me : D.opp, t: fmtT(f.t), kil: D.nm(k), vic: D.nm(vi), via: f.via }) : vi ? S(P.openV, { t: fmtT(f.t), vic: D.nm(vi) }) : '');
    } else parts.push(S(P.openN, { me: D.me, opp: D.opp }));
    const mm = moments(D); mm.list.forEach(m => parts.push(m.txt));
    parts.push(S(draw ? P.endD : won ? P.endW : P.endL, { me: D.me, opp: D.opp, sc: `${D.sc[0]}:${D.sc[1]}`, bb: `${D.b[0]}:${D.b[1]}` }));
    return { text: parts.filter(Boolean).join(' '), top: mm.top };
  }

  function pPlayers(D) {
    const A = AN(), res = D.res, won = res.winner === D.my, draw = res.winner === -1, con = D.con, out = [];
    const best = D.mine.reduce((a, u) => (con(u) > con(a) ? u : a)), share = u => (D.mineTot ? con(u) / D.mineTot : 0);
    out.push(S(best.healed > best.dmg ? P.starH : P.starD, { ...D.pv(best), dmg: num(best.dmg), heal: num(best.healed), k: best.kills, d: best.deaths, pct: Math.round(share(best) * 100) }));
    const rest = D.mine.filter(u => u !== best), worst = rest.reduce((a, u) => (!a || share(u) - u.deaths * A.slumpDeath < share(a) - a.deaths * A.slumpDeath ? u : a), null);
    const slump = worst && (worst.deaths >= A.slumpDeaths || share(worst) <= A.slumpShare);
    if (slump) out.push(S(worst.deaths >= A.slumpDeaths ? P.badD : P.badS, { ...D.pv(worst), dmg: num(worst.dmg), d: worst.deaths, k: worst.kills, pct: Math.round(share(worst) * 100) }));
    else out.push(S(won || draw ? P.noBad : P.noBadL, {}));
    const tk = rest.filter(u => u !== worst).reduce((a, u) => (!a || u.taken > a.taken ? u : a), null);
    if (tk && D.mineTaken && tk.taken / D.mineTaken >= A.tankShare && tk.deaths <= 1) out.push(S(P.tank, { ...D.pv(tk), pct: Math.round(tk.taken / D.mineTaken * 100), taken: num(tk.taken), d: tk.deaths }));
    if (!won) {
      const os = D.theirs.reduce((a, u) => (con(u) > con(a) ? u : a));
      out.push(S(P.oppStar, { ...D.pv(os), opp: D.opp, dmg: num(os.dmg), k: os.kills }));
    }
    if (D.u[0] === 0) out.push(S(P.ult0, {}));
    else if (D.u[1] - D.u[0] >= 2) out.push(S(P.ultLess, { a: D.u[0], b: D.u[1] }));
    else if (D.u[0] - D.u[1] >= 2) out.push(S(P.ultMore, { a: D.u[0], b: D.u[1] }));
    return out.join(' ');
  }

  /* 개인 지시가 결과와 이어졌는지: +면 성공, -면 실패, 0이면 언급 안 함 */
  function judgeTac(c, id, u, D, A) {
    const sh = D.mineTot ? (u.dmg + u.healed) / D.mineTot : 0, tk = D.mineTaken ? u.taken / D.mineTaken : 0;
    if (c === 'act' && id === 'rush') return u.deaths >= A.rushDeaths ? -2 : (u.kills >= 2 && u.deaths <= 1 ? 2 : 0);
    if (c === 'act' && id === 'retreat') return u.deaths <= 1 && sh >= 0.3 ? 2 : (sh < A.slumpShare ? -1 : 0);
    if (c === 'duty' && id === 'hunt') return u.kills >= 2 ? 2 : (u.kills === 0 && u.deaths >= 2 ? -2 : 0);
    if (c === 'duty') return u.deaths <= 1 ? 1 : (u.deaths >= A.rushDeaths ? -1 : 0);
    if (c === 'pos' && id === 'front') return u.deaths >= A.rushDeaths ? -2 : (u.deaths <= 1 && tk >= A.tankShare ? 2 : 0);
    if (c === 'pos' && id === 'cover') return u.deaths <= 1 && sh >= 0.3 ? 2 : 0;
    if (c === 'aim') return u.kills >= 2 ? 1 : (u.kills === 0 && u.deaths >= 2 ? -1 : 0);
    if (c === 'ult' && id === 'burst') return u.ults >= 2 ? 1 : 0;
    if (c === 'ult' && (id === 'save' || id === 'clutch')) return u.ults === 0 ? -1 : 0;
    return 0;
  }

  /* 밴픽 카운터: 상성표(CONFIG.news.analysis.counter)로 양 팀 조합을 비교 */
  function counterRead(D) {
    const A = AN(), { M, my, op, res } = D, rl = id => (CONFIG.fighters[id] || {}).role, mf = M.picks[my] || [], tf = M.picks[op] || [], won = res.winner === my;
    let s = 0, good = null, bad = null;
    mf.forEach(a => tf.forEach(b => {
      const ra = rl(a), rb = rl(b);
      if ((A.counter[ra] || []).includes(rb)) { s++; good = good || [a, b]; }
      if ((A.counter[rb] || []).includes(ra)) { s--; bad = bad || [a, b]; }
    }));
    D.ctr = s;
    let t = s > 0 ? S(won ? P.ctrPW : P.ctrPL, { gA: F(good[0]), gB: F(good[1]) })
      : s < 0 ? S(won ? P.ctrNW : P.ctrNL, { bA: F(bad[1]), mA: F(bad[0]), opp: D.opp })
        : S(P.ctrE, {});
    const bans = ((M.bans && M.bans[my]) || []).map(F);
    if (bans.length && chance(0.5)) t += ' ' + S(P.ban, { ban: bans[0] });
    return t;
  }

  function pTactics(D) {
    const A = AN(), { M, res, my, op } = D, won = res.winner === my, ok = won || res.winner === -1, T = CONFIG.tactics, mt = M.teams[my], st = mt.strategy, out = [];
    const sv = id => tacVal(T.team, st, id), nmOf = id => optName(T.team, id, sv(id));
    const [kA, kB] = D.k, [bA, bB] = D.b;
    const stance = STANCE[sv('stance')] ? sv('stance') : 'balanced';
    const good = { slay: kA > kB, objective: bA > bB || (bA === bB && won), capture: D.hp[0] >= D.hp[1], defend: ok, balanced: won }[stance];
    let line = S(STANCE[stance][good ? 'g' : 'b'], { nm: nmOf('stance'), kk: `${kA}:${kB}`, bb: `${bA}:${bB}`, hpA: D.hp[0], hpB: D.hp[1], dA: D.d[0], opp: D.opp });
    const os = optName(T.team, 'stance', tacVal(T.team, M.teams[op].strategy, 'stance'));
    if (os !== nmOf('stance')) line += ` 상대 ${D.opp}의 기조는 '${os}'.`;
    out.push(line);
    out.push(counterRead(D));
    const picks = [];
    D.mine.forEach(u => {
      const raw = mt.tactics && mt.tactics[u.slot]; if (!raw) return;
      ['act', 'duty', 'pos', 'aim', 'ult'].forEach(c => {
        const cat = T.categories.find(x => x.id === c), id = cat ? tacVal(T.categories, raw, c) : ''; if (!cat || id === cat.neutral) return;
        const sc = judgeTac(c, id, u, D, A); if (sc) picks.push({ u, c, id, sc, cat: cat.name });
      });
    });
    picks.sort((a, b) => Math.abs(b.sc) - Math.abs(a.sc) || Math.random() - 0.5);
    const used = new Set();
    picks.forEach(p => {
      if (used.size >= A.maxTactic || used.has(p.u.id)) return; used.add(p.u.id);
      out.push(S(p.sc > 0 ? P.tacG : P.tacB, { ...D.pv(p.u), opt: optName(T.categories, p.c, p.id), cat: p.cat, k: p.u.kills, d: p.u.deaths }));
    });
    if (!used.size) out.push(S(P.tacNone, {}));
    const bp = sv('boss');
    if (BOSSP[bp]) out.push(S(BOSSP[bp][{ contest: bA > bB, steal: bA >= 1, yield: kA > kB }[bp] ? 'g' : 'b'], { nm: nmOf('boss'), bA, bb: `${bA}:${bB}`, kk: `${kA}:${kB}` }));
    const ld = sv('lead'), tr = sv('trail');
    if (SCOREP[ld] && D.lead[my] >= 2) out.push(S(SCOREP[ld][won ? 'g' : 'b'], { nm: nmOf('lead') }));
    else if (SCOREP[tr] && D.lead[op] >= 2) out.push(S(SCOREP[tr][won ? 'g' : 'b'], { nm: nmOf('trail') }));
    return out.join(' ');
  }

  function pNext(D) {
    const A = AN(), { G, M, res, my } = D, won = res.winner === my, draw = res.winner === -1, T = [];
    if (D.d[0] >= A.deathsHigh) T.push({ p: 5, txt: S(['재출격 공백을 줄이는 것이 최우선이다. 이번 경기 팀 데스는 {d}회였다.', '무리한 교전을 줄여 데스({d}회)부터 관리해야 한다.'], { d: D.d[0] }) });
    if (D.lostLead) T.push({ p: 4, txt: S(['앞서던 점수를 지키는 법이 숙제다. 리드 중 \'굳히기\' 지침을 검토해 볼 만하다.', '리드를 잡은 뒤 흐름을 놓친 장면을 되짚어야 한다.'], {}) });
    if (D.b[0] < D.b[1]) T.push({ p: 4, txt: S(['보스 싸움에서 {ab:으로/로} 밀렸다. 등장 시각에 맞춘 합류와 보스 방침을 다시 점검하자.', '보스 타이밍에서의 손해({a}:{b})를 줄이는 것이 과제다.'], { a: D.b[0], b: D.b[1], ab: `${D.b[0]}:${D.b[1]}` }) });
    if (res.sudden && !won && !draw) T.push({ p: 3, txt: S(['정규 시간 안에 점수 차를 벌려 서든데스를 피하는 운영이 필요하다.'], {}) });
    if (D.u[0] <= A.ultLow) T.push({ p: 3, txt: S(['궁극기 사용이 적었다. 궁 타이밍 설정과 자원 관리를 손볼 필요가 있다.', '궁극기를 아끼다 놓친 장면이 없었는지 확인해 보자.'], {}) });
    if (D.k[0] < D.k[1]) T.push({ p: 3, txt: S(['교전에서 {ab:으로/로} 밀린 만큼 포지션과 집중 지시를 다시 점검할 필요가 있다.', '처치 수({a}:{b})를 따라잡을 교전 구도가 필요하다.'], { a: D.k[0], b: D.k[1], ab: `${D.k[0]}:${D.k[1]}` }) });
    if (D.ctr < 0) T.push({ p: 2, txt: S(['밴픽 단계에서 상성 열세를 피하는 선택이 필요하다.', '다음엔 상대 조합을 의식한 밴 카드가 과제다.'], {}) });
    if (won) {
      const os = D.theirs.reduce((a, u) => (D.con(u) > D.con(a) ? u : a));
      T.push({ p: 1, txt: S(['지금의 운영을 유지하되 상대 {who:을/를} 더 일찍 끊을 방법을 찾아야 한다.', '흐름은 좋다. 승리에 취하지 말고 폼과 멘탈 관리에 신경 쓰자.'], { who: D.nm(os) }) });
    }
    if (!T.length) T.push({ p: 0, txt: S(['큰 약점은 보이지 않는다. 지금의 균형을 유지하면서 변수 관리에 집중하자.', '뚜렷한 숙제는 없다. 다음 경기도 같은 밸런스로 가면 된다.'], {}) });
    T.sort((a, b) => b.p - a.p || Math.random() - 0.5);
    let intro = '';
    if (M.kind === 'league') {
      const nm = League.playerMatch(G), oid = nm && (nm.a === 'player' ? nm.b : nm.a);
      if (oid) intro = S(['다음 상대는 {n}, 현재 {r}위({rec}).', '다음 경기는 {n:과/와}의 맞대결 — {r}위({rec}).'], { n: League.name(G, oid), r: rk(G, oid), rec: rec(G, oid) });
    }
    return [intro, ...T.slice(0, A.maxTask).map(x => x.txt)].filter(Boolean).join(' ');
  }

  function analysis(G, info, date) {
    const { won, draw, res, M } = info;
    if (!res || !res.rec || !res.units || !res.units.length || !M || !M.teams || !M.picks || !wantAnalysis(res, M)) return null;
    try {
      const D = digest(G, info), mood = draw ? 'neutral' : won ? 'win' : 'lose';
      const t1 = pTurning(D), body = ['【승부처】 ' + t1.text, '【수훈·부진】 ' + pPlayers(D), '【전술 평가】 ' + pTactics(D), '【다음 과제】 ' + pNext(D)];
      const top = t1.top, pool = HEAD[top ? top.kind : (draw ? 'draw' : won ? 'win' : 'lose')];
      const star = D.mine.reduce((a, u) => (D.con(u) > D.con(a) ? u : a)), head = S(pool, { me: D.me, opp: D.opp, ...(top ? top.hv : {}) });
      const v = { team: D.me, opp: D.opp, mvp: D.nm(star), score: `${D.sc[0]}:${D.sc[1]}` };
      return mk(G, date, 'analysis', 'me', head, body, comments(mood, v, 5, ['analyst', 'analyst', 'meme', mood === 'lose' ? 'salty' : 'hype', 'cope']), { dupKey: 'an' + M.label + D.opp + League.isoDate(date) });
    } catch (e) { console.warn('News.analysis 실패', e); return null; }
  }

  /* ----- 라운드 종료 ----- */
  function afterRound(G, date) {
    const rows = League.sorted(G), me = rows.findIndex(t => t.id === 'player') + 1;
    const lead = rows[0], v = { team: G.teamName, opp: lead.name, mvp: '', score: '' };
    const rep = ensureRep(G);
    // 순위 보너스/패널티 (소폭)
    if (me === 1) shiftRep(G, 1, '단독 선두 여론');
    else if (me >= rows.length - 1) shiftRep(G, -1, '하위권 압박');
    const head = rnd([
      `${League.lgOf(G).name} ${G.league.round}라운드 마감 — 선두 ${lead.name}`,
      `순위표 갱신: ${G.teamName} ${me}위 / 평판 ${rep.v}`
    ]);
    const body = [
      `${G.league.round}라운드가 끝났다. 선두는 ${lead.name}(${lead.w}승 ${lead.l}패).`,
      `${G.teamName}${hasB(G.teamName) ? '은' : '는'} ${me}위. 감독 평판은 ${rep.v}(${repLabel(rep.v)}).`,
      me <= 3 ? '상위권 싸움 깊게 물고 있다는 평.' : me >= Math.ceil(rows.length * 0.7) ? '강등권 공포 밈이 돌기 시작.' : '중위권 정체라는 냉정한 시선.'
    ];
    return mk(G, date, 'round', 'league', head, body, comments(me <= 3 ? 'win' : me >= rows.length - 2 ? 'lose' : 'neutral', v, 5));
  }

  function tourStart(G, kind, t, date) {
    const v = { team: G.teamName, opp: '', mvp: '', score: '' };
    return mk(G, date, 'tour', 'intl', `${t.name} 개막 — ${G.teamName} 출사표`, [
      `${t.name}가 개막했다. ${G.teamName}${hasB(G.teamName) ? '은' : '는'} 우승을 목표로 내걸었다.`,
      `국제 무대 여론은 냉정하다. 한 경기 한 경기가 평판에 직결된다.`
    ], comments('neutral', v, 5, ['hype', 'analyst', 'rival', 'meme', 'salty']), { hot: true });
  }
  function tourRound(G, t, ri, M, date) {
    const lines = (t.rounds[ri] || []).filter(m => m.winner).map(m => {
      const w = League.name(G, m.winner), l = League.name(G, m.winner === m.a ? m.b : m.a); return `${w} def. ${l}`;
    });
    if (!lines.length) return null;
    const v = { team: G.teamName, opp: '', mvp: '', score: '' };
    return mk(G, date, 'tour', 'intl', `${t.name} ${ri + 1}라운드 결과`, [`${t.name} 경기가 종료되었다.`, ...lines.slice(0, 6)], comments('neutral', v, 4, ['analyst', 'hype', 'meme', 'rival']));
  }
  function tourEnd(G, kind, date) {
    const t = G[kind], ch = t.champion, nm = League.name(G, ch), me = ch === 'player';
    const v = { team: G.teamName, opp: nm, mvp: '', score: '' };
    if (me) shiftRep(G, kind === 'worlds' ? 12 : kind === 'msi' ? 8 : 6, `${t.name} 우승`);
    else if (t.seeds && t.seeds.includes('player')) shiftRep(G, -3, `${t.name} 준우승 이하`);
    const head = me ? `${G.teamName}, ${t.name} 우승!! 여론 폭발` : `${nm}, ${t.name} 정상 — ${G.teamName}은 다음을 기약`;
    const body = [
      `${t.name} 결승 종료. 우승은 ${nm}.`,
      me ? '감독 평판이 크게 올랐다. 커뮤니티도 잠시 칭찬 모드.' : '아쉬운 결과. 댓글창은 차가웠다.'
    ];
    return mk(G, date, 'tour', 'intl', head, body, comments(me ? 'win' : 'lose', v, 8), { hot: true });
  }
  function seasonEnd(G, date) {
    const rank = League.rankOf(G, 'player'), y = League.yearOf(G), v = { team: G.teamName, opp: '', mvp: '', score: '' };
    shiftRep(G, rank === 1 ? 5 : rank <= 3 ? 2 : rank >= 8 ? -3 : 0, `시즌 ${rank}위 정산`);
    const rep = ensureRep(G);
    return mk(G, date, 'season', 'me', `${y}년 시즌 종료 — ${G.teamName} ${rank}위 · 평판 ${rep.v}`, [
      `${y}년 시즌이 끝났다. 최종 ${rank}위.`,
      `감독 평판 ${rep.v}(${repLabel(rep.v)}).`,
      ...(G.seasonLines || []).map(l => l + '.')
    ], comments(rank <= 3 ? 'win' : 'lose', v, 6));
  }
  function seasonStart(G, date) {
    const y = League.yearOf(G), v = { team: G.teamName, opp: '', mvp: '', score: '' };
    ensureRep(G);
    // 시즌 시작 시 폼 완만 회귀
    if (G.club && G.club.roster) G.club.roster.forEach(id => {
      const p = Pros.get(G, id); if (!p) return;
      ensureProMood(p);
      p.form = clamp(Math.round(p.form * 0.85 + 50 * 0.15), 0, 100);
    });
    return mk(G, date, 'season', 'league', `${y}년 시즌 개막 — 여론은 리셋에 가깝다`, [
      `${y}년 ${League.lgOf(G).name} 리그 개막.`,
      `${G.teamName} 감독 평판 ${ensureRep(G).v}. 개막 전 기대와 조롱이 공존한다.`
    ], comments('neutral', v, 6, ['hype', 'analyst', 'salty', 'meme', 'cope']), { hot: true });
  }
  function halfEnd(G, date) {
    const lead = League.sorted(G)[0], v = { team: G.teamName, opp: '', mvp: '', score: '' };
    return mk(G, date, 'season', 'league', `전반기 종료 — 선두 ${lead.name}, MSI 앞두고 여론 분분`, [
      `전반기 종료. 선두 ${lead.name}. ${G.teamName}${hasB(G.teamName) ? '은' : '는'} ${League.rankOf(G, 'player')}위.`,
      '국제전 앞두고 감독 역량 재평가 기사가 나온다.'
    ], comments('neutral', v, 5, ['analyst', 'hype', 'salty', 'meme', 'rival']));
  }
  /* 주제 고정 댓글 — 경기 일반 댓글 풀과 분리 */
  function topicComments(topic, v, n) {
    const team = v.team || '', opp = v.opp || '', champ = v.mvp || '', rate = v.score || '';
    const money = v.money || rate;
    const pools = {
      meta: [
        `${champ} 요즘 진짜 많이 보이긴 함. 밴 우선순위 올려야 하는 거 아니냐`,
        `픽률 ${rate}%면 급등 맞긴 한데, 승률이 따라오는지가 중요함`,
        `연습실에서 ${champ} 연습 영상 돈다던 얘기 있었는데 이거였나`,
        `${champ} 카운터 조합 연구 안 하면 다음 주부터 고생각`,
        `메타 탄다고 무조건 좋은 건 아님. 숙련도 없으면 독임`,
        `우리 팀도 ${champ} 숙련자 있나? 없으면 밴하는 게 나을 듯`,
        `데이터만 보면 납득됨. 감정으로 까지 말자`,
        `${opp}가 ${champ} 올리면 운영이 많이 달라지긴 함`,
        `밴픽 페이즈부터 ${champ} 체크하는 습관 들여야 함`,
        `급등 챔프는 한동안 과대평가되는 구간 있음. 냉정하게 보자`
      ],
      interview: [
        `우승만 본다는 말은 누구나 하지. 성적으로 증명해야지`,
        `${opp} 감독 인터뷰 톤 보니까 자신 있는 척하는데 성적은 애매했음`,
        `선수들 반응은 어떨지. 감독만 열정 넘치면 소용없음`,
        `말발은 좋은데 밴픽이 못 따라가면 말짱 도루묵`,
        `여론은 한 번만 지면 바로 뒤집힘. 발언 조심해야 함`,
        `${opp} 팬덤은 좋아하겠네. 우리 쪽은 일단 지켜보자`,
        `인터뷰용 멘트 치곤 무난함. 특별한 정보 없음`,
        `다음 빅매치 결과 보고 평가하자. 지금은 말뿐`
      ],
      leak: [
        `${champ} 연습 영상? 고의 유출인지 스파이인지부터 의문`,
        `동선 보면 신규 빌드 연습하는 것 같긴 함`,
        `과한 확대 금지. 연습이랑 실전은 다름`,
        `저 조합 실전 나오면 밴픽 난이도 확 올라감`,
        `${team} 측에서 해명 안 나오면 커뮤니티는 계속 해석할 듯`,
        `영상 퀄 보니까 연습실 캠 유출 쪽 무게가 실림`,
        `카운터 픽 미리 준비하는 팀이 이득 봄`
      ],
      rivalry: [
        `${team} vs ${opp} 관련이면 댓글창 항상 이렇게 됨`,
        `라이벌 팬덤 감성 싸움을 데이터 싸움으로 가져가자`,
        `루머에 발끈하는 거 자체가 라이벌 맞긴 함 ㅋㅋ`,
        `진위 불명인데 감정만 앞서면 양쪽 다 손해야`,
        `${opp} 쪽 커뮤니티도 난리라던데. 시즌 내내 이런 식일 듯`,
        `더비 감성은 인정. 근데 경기력으로 말하자`
      ],
      sponsor_offer: [
        `${opp}가 우리 구단에 붙으려는 거면 평판이 어느 정도 회복됐다는 뜻`,
        `금액 ${money}이면 ${v.tier || '스폰서'}치곤 나쁘지 않은데`,
        `광고 붙는 건 좋은데, 성적이 안 받쳐주면 재계약도 없음`,
        `이제 자금 숨통 트이나. 이적시장에서 한 명 더 볼 수 있겠는데`,
        `브랜드 이미지 생각하면 ${opp} 쪽도 손해 보는 계약은 아닐 듯`,
        `수락할지 말지는 연봉 구조랑 맞춰 봐야 함`,
        `커뮤니티: 돈 들어온다 = 좋음. 단, 방심 금지`,
        `평판 ${v.rep || ''} 기준으로 제안 온 거라면 납득됨`
      ],
      sponsor_yes: [
        `${opp} 계약 확정이면 유니폼에 로고 붙겠구만`,
        `+${money} 입금이면 당장 적자 메꾸는 데 도움 됨`,
        `스폰서 붙었다고 성적이 오르는 건 아님. 착각 금물`,
        `이제 구단 운영 여유 생기면 로스터 보강 압박도 커짐`,
        `${opp} 측 보도자료 톤 보니까 장기 파트너 원하나 봄`,
        `팬덤 반응 괜찮네. 적어도 "왜 저런 브랜드" 소리는 없음`,
        `계약금 들어온 김에 연습 시설/분석 인력에 쓰면 좋겠다`
      ],
      sponsor_no: [
        `거절한 이유가 뭐임? 금액 문제인가 조건 문제인가`,
        `단기 자금보다 브랜드 이미지가 안 맞았을 수도`,
        `거절도 전략일 수 있음. 더 큰 스폰서 노리는 건가`,
        `자금 여유 있으면 모를까, 타이트하면 아쉬운 선택`,
        `${opp} 팬들은 황당해하겠다 ㅋㅋ`,
        `여론 반반인 게 정상. 정답은 없음`
      ]
    };
    const list = pools[topic] || pools.meta;
    const out = [], used = new Set();
    const tones = topic.startsWith('sponsor')
      ? ['analyst', 'hype', 'salty', 'meme', 'cope']
      : ['analyst', 'meme', 'salty', 'hype', 'rival', 'toxic'];
    for (let i = 0; i < n; i++) {
      let text = '', guard = 0;
      do { text = rnd(list); guard++; } while (used.has(text) && guard < 12);
      used.add(text);
      const tone = tones[i % tones.length];
      out.push({
        u: nick(),
        tone,
        t: text,
        like: Math.floor(Math.random() * 50) + (tone === 'analyst' ? 18 : 8)
      });
    }
    return out.sort((a, b) => b.like - a.like);
  }

  function gossip(G, date) {
    const ts = G.league.teams.filter(t => t.id !== 'player'); if (!ts.length) return null;
    const lg = G.leagueId;
    const items = [];

    /* 1) 실제 픽률 데이터 기반 메타 가십 (경기 수 충분할 때만) */
    try {
      if (typeof Stats !== 'undefined' && Stats.leagueRates) {
        const rates = Stats.leagueRates(G, lg);
        const pickPack = rates && rates.picks;
        const picks = (pickPack && pickPack.list) || [];
        const games = (pickPack && pickPack.g) || (Stats.get(G).lg[lg] && Stats.get(G).lg[lg].g) || 0;
        if (games >= 6 && picks.length) {
          const top = picks.slice(0, 5);
          const rising = top.filter(p => Math.round(p.rate * 100) >= 18);
          if (rising.length) {
            const p = rnd(rising);
            const nm = F(p.id);
            const pct = Math.round(p.rate * 100);
            items.push({
              topic: 'meta',
              head: `${League.lgOf(G).name} ${nm} 픽률 ${pct}% — 메타 안착?`,
              body: [
                `리그 집계 ${games}경기 기준 ${nm} 픽률이 ${pct}%로 상위권이다.`,
                `연습·밴픽 단계에서 체크 대상이 되고 있다.`,
                `단순 루머가 아니라 리그 기록에 기반한 동향이다.`
              ],
              v: { team: G.teamName, opp: '', mvp: nm, score: String(pct) }
            });
          }
          /* 특정 팀 픽 편중 */
          const t = rnd(ts);
          const tr = Stats.teamRates(G, lg, t.name);
          const tp = (tr && tr.picks && tr.picks.list) || [];
          if (tp.length && Math.round(tp[0].rate * 100) >= 30) {
            const p = tp[0];
            const pct = Math.round(p.rate * 100);
            items.push({
              topic: 'meta',
              head: `${t.name}, ${F(p.id)} 의존도 ${pct}% — 원툴 논란`,
              body: [
                `${t.name} 경기에서 ${F(p.id)} 픽 비중이 ${pct}%에 달한다.`,
                `숙련 픽이면 강점이지만, 밴 당하면 조합이 흔들린다는 지적이 나온다.`,
                `상대 팀 밴픽에서 최우선 견제 대상으로 꼽힐 전망이다.`
              ],
              v: { team: t.name, opp: G.teamName, mvp: F(p.id), score: String(pct) }
            });
          }
        }
      }
    } catch (e) { /* stats 없으면 아래 일반 가십만 */ }

    /* 2) 인터뷰 / 라이벌 루머 (데이터 무관, 댓글은 주제에 맞게) */
    {
      const t = rnd(ts);
      items.push({
        topic: 'interview',
        head: `${t.name} 감독 인터뷰 "목표는 우승뿐"`,
        body: [
          `${t.name} 감독이 공식 인터뷰에서 우승을 목표로 내걸었다.`,
          `선수 기용·밴픽 방향에 대한 구체적 언급은 없어 해석이 분분하다.`,
          `커뮤니티 반응은 "말은 누구나 한다" 쪽이 우세하다.`
        ],
        v: { team: G.teamName, opp: t.name, mvp: '', score: '' }
      });
      items.push({
        topic: 'rivalry',
        head: `${G.teamName}·${t.name} 관련 루머에 팬덤 반응 분분`,
        body: [
          `양 팀 팬 커뮤니티를 중심으로 출처 불명의 루머가 돌고 있다.`,
          `구단 차원의 공식 입장은 아직 없다.`,
          `라이벌 감성이 섞이면서 감정적 댓글이 늘고 있다.`
        ],
        v: { team: G.teamName, opp: t.name, mvp: '', score: '' }
      });
    }

    /* 3) 연습 영상 가십 — 실제 상위 픽 챔프를 소재로 */
    {
      let fid = rnd(Object.keys(CONFIG.fighters));
      try {
        if (typeof Stats !== 'undefined' && Stats.topBy) {
          const top = Stats.topBy(G, 'g', 5);
          if (top && top.length) fid = rnd(top).id || fid;
        }
      } catch (e) {}
      const t = rnd(ts);
      items.push({
        topic: 'leak',
        head: `[가십] ${t.name} ${F(fid)} 연습 영상 유출 의혹`,
        body: [
          `${t.name} 연습실로 추정되는 영상에서 ${F(fid)} 동선이 포착됐다는 주장이 나왔다.`,
          `진위는 확인되지 않았고, 구단 측 해명은 없다.`,
          `실전 반영 여부와 별개로 밴픽 견제 목록에 오를 가능성은 있다.`
        ],
        v: { team: t.name, opp: G.teamName, mvp: F(fid), score: '' }
      });
    }

    const it = rnd(items);
    return mk(G, date, 'gossip', 'league', it.head, it.body, topicComments(it.topic, it.v, 6), { topic: it.topic });
  }

  function sponsorOffer(G, offer, date) {
    const money = Pros.money(offer.amount);
    const v = { team: G.teamName, opp: offer.brand, mvp: '', score: money, money, tier: offer.tier, rep: offer.rep };
    return mk(G, date, 'gossip', 'me',
      `[스폰서] ${offer.brand}, ${G.teamName}에 ${offer.tier} 제안`,
      [
        `평판 ${offer.rep} 구단으로 평가받으며 ${offer.brand} 측이 ${offer.tier} 계약을 타진했다.`,
        `제안 금액 ${money}. 구단 관리 화면에서 수락/거절할 수 있다.`,
        '브랜드 노출 조건과 계약 기간은 비공개. 커뮤니티는 금액·타이밍에 집중하는 분위기다.'
      ],
      topicComments('sponsor_offer', v, 6),
      { hot: true, sponsorId: offer.id, topic: 'sponsor' }
    );
  }
  function sponsorDeal(G, offer, accepted, date) {
    const money = Pros.money(offer.amount);
    const v = { team: G.teamName, opp: offer.brand, mvp: '', score: money, money, tier: offer.tier, rep: offer.rep };
    if (accepted) {
      return mk(G, date, 'gossip', 'me',
        `${G.teamName}, ${offer.brand} ${offer.tier} 계약 체결 (+${money})`,
        [
          `${offer.brand}와 공식 계약을 맺었다.`,
          `계약금 ${money}이 구단 자금에 입금됐다.`,
          `${offer.tier} 등급 스폰서로, 시즌 운영 자금에 바로 반영된다.`
        ],
        topicComments('sponsor_yes', v, 6),
        { hot: true, topic: 'sponsor' }
      );
    }
    return mk(G, date, 'gossip', 'me',
      `${G.teamName}, ${offer.brand} ${offer.tier} 제안 거절`,
      [
        `${offer.brand}의 ${offer.tier} 제안(${money})을 거절했다.`,
        '구단 측은 구체적 사유를 밝히지 않았다.',
        '단기 자금보다 조건·이미지 문제를 봤다는 해석이 나온다.'
      ],
      topicComments('sponsor_no', v, 5),
      { topic: 'sponsor' }
    );
  }
  return {
    preview, draft, result, analysis, afterRound, tourStart, tourRound, tourEnd,
    seasonEnd, seasonStart, halfEnd, gossip, sponsorOffer, sponsorDeal, TONES,
    ensureRep, repLabel, shiftRep, ensureProMood
  };
})();
