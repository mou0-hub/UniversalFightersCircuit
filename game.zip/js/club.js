/* club.js — 구단 관리: 자금 · 선수단 · 라인업(1/2/3번) · 시즌 정산(구단주 지급 − 연봉) + 화면에서 쓰는 액션 */

const Club = (() => {
  const C = () => CONFIG.club;

  /* 새 커리어: 구단 자금 + 리그 난이도에 맞는 기본 선수단 5명 지급 (G.league 이전에 호출)
     등급은 AI와 같은 aiMix를 쓰고, 시작/지급 크레딧이 리그 수준에 맞게 책정되어 있음 */
  function init(G) {
    G.pros = { seq: 0, by: {} }; G.market = { fa: [], round: -99 };
    const funds = C().startFunds[G.difficulty] || C().startFunds.normal;
    G.club = { funds, roster: [], lineup: [null, null, null], finance: null, sponsorEarned: 0, sponsorCD: 0, pendingSponsor: null, ownerGoal: null };
    const level = G.difficulty || 'normal';
    const lgId = G.leagueId || 'kr';
    const starters = [];
    for (let i = 0; i < 5; i++) {
      const p = Pros.gen(G, Pros.mixGrade(level), { lg: lgId });
      p.team = 'player';
      starters.push(p);
    }
    starters.sort((a, b) => b.ovr - a.ovr);
    G.club.roster = starters.map(p => p.id);
    G.club.lineup = [starters[0].id, starters[1].id, starters[2].id];
  }

  /* 시즌 시작마다: 리그 AI 팀 선수 배정 + 시장 갱신 */
  function seasonSetup(G) {
    const lg = League.lgOf(G);
    G.league.teams.forEach(t => {
      if (t.isPlayer) return;
      const teamLg = t.lg || lg.id;
      t.pros = Pros.genTeam(G, t.level || lg.diff, teamLg);
      t.pros.forEach(id => {
        const p = Pros.get(G, id); p.team = t.id;
        /* 시즌마다 폼·멘탈 재배치 (완전 랜덤에 가깝게 흔들림) */
        p.form = 35 + Math.floor(Math.random() * 50);
        p.mental = 50 + Math.floor(Math.random() * 45);
      });
    });
    Pros.purge(G); Market.refresh(G, true); ensureRoster(G);
    if (!G.club.ownerGoal || G.club.ownerGoal.season !== G.season) assignGoal(G);
  }

  /* 구버전 세이브 보정 */
  function migrate(G) {
    if (!G.club) { G.pros = G.pros || { seq: 0, by: {} }; G.market = G.market || { fa: [], round: -99 }; G.club = { funds: C().startFunds[G.difficulty] || C().startFunds.normal, roster: [], lineup: [null, null, null], finance: null }; }
    if (G.pros && G.club.roster && G.club.lineup) ensureRoster(G);
    if (G.club.ownerGoal === undefined) G.club.ownerGoal = null;
    if (G.club.sponsorEarned == null) G.club.sponsorEarned = 0;
    if (G.league && G.league.teams.some(t => !t.isPlayer && !t.pros)) seasonSetup(G);
    // 구버전 세이브: 시즌 중인데 목표가 없으면 즉시 배정
    if (!G.club.ownerGoal && G.phase === 'season' && G.league) {
      try { assignGoal(G); } catch (e) { /* 함수 정의 전 로드 순서 대비 */ }
    }
  }

  const roster = G => G.club.roster.map(id => Pros.get(G, id)).filter(Boolean);
  const lineup = G => G.club.lineup.map(id => (id ? Pros.get(G, id) : null));
  const ready = G => !!G.club && G.club.lineup.every(id => id && G.club.roster.includes(id));
  const brains = G => G.club.lineup.map(id => Pros.grade(G, id));
  const moods = G => G.club.lineup.map(id => {
    const p = Pros.get(G, id);
    if (!p) return { form: 55, mental: 70, trouble: 0, slack: 0 };
    if (typeof News !== 'undefined' && News.ensureProMood) News.ensureProMood(p);
    return { form: p.form ?? 55, mental: p.mental ?? 70, trouble: p.trouble ?? 0, slack: p.slack ?? 0, nick: p.nick, sk: Pros.skills(p) };
  });
  const payroll = G => roster(G).reduce((s, p) => s + p.salary, 0);

  function setSlot(G, id, slot) {
    if (!G.club.roster.includes(id)) return false;
    G.club.lineup = G.club.lineup.map(x => (x === id ? null : x)); G.club.lineup[slot] = id; return true;
  }
  function clearSlot(G, slot) { G.club.lineup[slot] = null; }
  function autoFill(G) {
    const free = roster(G).filter(p => !G.club.lineup.includes(p.id)).sort((a, b) => b.ovr - a.ovr);
    G.club.lineup = G.club.lineup.map(x => x || (free.length ? free.shift().id : null));
  }

  /* 안전장치: 선수단이 3명 미만이면(계약 만료 + 자금 부족 등) 무료 C급 신인을 보충해 경기 불능을 막습니다 */
  function ensureRoster(G) {
    const made = [];
    while (G.club.roster.length < 3) {
      const p = Pros.gen(G, 'C', { lg: G.leagueId || 'kr' });
      p.team = 'player'; p.years = 1; G.club.roster.push(p.id); made.push(p);
    }
    G.club.lineup = G.club.lineup.map(id => (id && G.club.roster.includes(id) ? id : null));
    autoFill(G);
    return made;
  }

  function ownerPay(G, rank) {
    const o = C().owner, mul = o.leagueMul[League.lgOf(G).diff] || 1;
    const rk = rank >= 1 && rank <= o.rank.length ? o.rank[rank - 1] : 0;
    const lines = [{ k: '구단주 기본 지급', v: Math.round(o.base * mul) }, { k: `정규시즌 ${rank}위 보너스`, v: Math.round(rk * mul) }];
    [['playoff', 'league', '리그 우승'], ['msi', 'msi', 'MSI 우승'], ['worlds', 'worlds', '월드 챔피언십 우승']].forEach(([key, tk, name]) => {
      if (G[key] && G[key].champion === 'player') lines.push({ k: `${name} 보너스`, v: Math.round(o.trophy[tk] * mul) });
    });
    /* 평판 보너스: 55↑ 소폭, 70↑ 본격, 85↑ 대형 */
    const rep = (G.rep && typeof G.rep.v === 'number') ? G.rep.v : 50;
    let repMul = 0, repLabel = '';
    if (rep >= 85) { repMul = 0.28; repLabel = '평판 최고 보너스'; }
    else if (rep >= 70) { repMul = 0.16; repLabel = '평판 우대 보너스'; }
    else if (rep >= 55) { repMul = 0.07; repLabel = '평판 소폭 보너스'; }
    if (repMul > 0) {
      const baseSum = lines.reduce((s, x) => s + x.v, 0);
      lines.push({ k: `${repLabel} (${rep})`, v: Math.round(baseSum * repMul) });
    }
    return lines;
  }

  function settle(G) {
    const rank = League.rankOf(G, 'player'), pay = ownerPay(G, rank).slice();
    const sponsorSum = G.club.sponsorEarned || 0;
    if (sponsorSum > 0) pay.push({ k: '시즌 스폰서·광고 수입', v: sponsorSum });
    const income = pay.reduce((s, x) => s + x.v, 0), cost = payroll(G), out = [];
    const before = G.club.funds;
    /* sponsorEarned 는 이미 수락 시 입금됨 — 정산 합계에는 표시만, 중복 입금 금지 */
    G.club.funds += (income - sponsorSum) - cost;
    const expired = [];
    roster(G).forEach(p => { p.years--; p.age++; if (p.years <= 0) expired.push(p); });
    expired.forEach(p => { G.club.roster = G.club.roster.filter(x => x !== p.id); G.club.lineup = G.club.lineup.map(x => (x === p.id ? null : x)); p.team = null; p.years = 2; Market.ensure(G).fa.push(p.id); });
    const rookies = ensureRoster(G);
    const ev = evaluateGoal(G);
    if (ev && ev.success) pay.push({ k: `구단주 목표 달성 (${ev.goal.label})`, v: ev.bonus });
    const chDone = checkChallenges(G);
    G.club.finance = { season: G.season, income: pay, cost, before, after: G.club.funds, expired: expired.map(p => p.nick), sponsor: sponsorSum };
    out.push(`💰 구단주 지급 +${Pros.money(income - sponsorSum)} · 연봉 −${Pros.money(cost)} → 자금 ${Pros.money(G.club.funds)}`);
    if (ev) out.push(ev.success ? `🎯 구단주 목표 「${ev.goal.label}」 달성! 보너스 +${Pros.money(ev.bonus)}` : `🎯 구단주 목표 「${ev.goal.label}」 미달성 — 평판이 하락했습니다.`);
    chDone.forEach(c => out.push(`🏅 도전과제 「${c.name}」 달성 +${Pros.money(c.reward)}`));
    if (sponsorSum > 0) out.push(`📣 시즌 스폰서·광고 누적 +${Pros.money(sponsorSum)} (이미 입금됨)`);
    if (expired.length) out.push(`📄 계약 만료로 FA 시장에 나간 선수: ${expired.map(p => p.nick).join(', ')}`);
    if (rookies.length) out.push(`🆘 선수단이 부족해 구단이 신인 ${rookies.map(p => p.nick).join(', ')} 선수를 보충했습니다.`);
    if (G.club.funds < 0) out.push(`⚠ 구단 자금이 마이너스입니다. 선수 영입이 제한됩니다.`);
    G.club.sponsorEarned = 0;
    return out;
  }

  /* ----- 구단주 시즌 목표 ----- */
  function assignGoal(G) {
    const pools = (C().goals && C().goals.pools) || {};
    const diff = G.difficulty || (League.lgOf(G) && League.lgOf(G).diff) || 'normal';
    const noImport = ((CONFIG.pro.names || {}).foreignMax || {})[G.leagueId] === 0;
    const pool = (pools[diff] || pools.normal || []).filter(g => !(noImport && g.type === 'import'));
    if (!pool.length) { G.club.ownerGoal = null; return null; }
    // 직전 시즌 성공/실패와 같은 목표 반복 피하기
    const prevId = G.club.ownerGoal && G.club.ownerGoal.id;
    const cand = pool.filter(g => g.id !== prevId);
    const pick = (cand.length ? cand : pool)[Math.floor(Math.random() * (cand.length ? cand.length : pool.length))];
    G.club.ownerGoal = {
      id: pick.id, type: pick.type, target: pick.target, grade: pick.grade, bonusMul: pick.bonusMul, base: G.club.funds,
      label: pick.label, desc: pick.desc,
      status: 'active', pressure: 0, warned: false,
      season: G.season, setAt: G.league ? G.league.round : 0
    };
    return G.club.ownerGoal;
  }

  function goalProgress(G) {
    const g = G.club && G.club.ownerGoal;
    if (!g || g.status !== 'active') return null;
    const rank = League.rankOf(G, 'player');
    const st = G.league && G.league.standings && G.league.standings.player;
    const wins = st ? st.w : 0;
    const total = (CONFIG.league && CONFIG.league.rounds) || 24;
    const round = G.league ? G.league.round : 0;
    const mid = (CONFIG.league && CONFIG.league.midRound) || 12;
    let current = 0, ok = false, hint = '';
    switch (g.type) {
      case 'rank':
        current = rank || 99;
        ok = rank > 0 && rank <= g.target;
        hint = `현재 ${rank}위 / 목표 ${g.target}위 이내`;
        break;
      case 'wins':
        current = wins;
        ok = wins >= g.target;
        hint = `현재 ${wins}승 / 목표 ${g.target}승`;
        break;
      case 'playoff':
        current = rank || 99;
        ok = rank > 0 && rank <= (CONFIG.league.playoffTeams || 8);
        hint = `현재 ${rank}위 · 플레이오프권 ${CONFIG.league.playoffTeams || 8}위 이내`;
        break;
      case 'msi':
        current = rank || 99;
        ok = rank > 0 && rank <= (CONFIG.league.intlTeams || 4);
        // 전반기 종료 전엔 중간 순위로 추정
        hint = round < mid
          ? `전반 ${rank}위 · MSI 시드 ${CONFIG.league.intlTeams || 4}위 이내 필요`
          : `현재 ${rank}위 · MSI 시드 ${CONFIG.league.intlTeams || 4}위 이내`;
        break;
      case 'playoff_win':
        ok = !!(G.playoff && G.playoff.champion === 'player');
        hint = G.playoff
          ? (G.playoff.champion === 'player' ? '플레이오프 우승 달성' : (G.playoff.champion ? '플레이오프 탈락' : '플레이오프 진행 중'))
          : `현재 ${rank}위 · 일단 플레이오프 진출이 선행 조건`;
        break;
      case 'worlds':
        current = rank || 99;
        ok = !!(G.worlds && G.worlds.seeds && G.worlds.seeds.includes('player')) || (rank > 0 && rank <= (CONFIG.league.intlTeams || 4));
        hint = `현재 ${rank}위 · 월드 진출권 ${CONFIG.league.intlTeams || 4}위 이내`;
        break;
      case 'fundsUp':
        current = Math.round(G.club.funds - (g.base || 0));
        ok = current >= g.target;
        hint = `시즌 시작 대비 ${current >= 0 ? '+' : ''}${current} / 목표 +${g.target} 크레딧`;
        break;
      case 'grade': {
        const GR = { C: 0, B: 1, A: 2, S: 3 };
        current = roster(G).filter(p => GR[p.grade] >= GR[g.grade || 'A']).length;
        ok = current >= g.target;
        hint = `${g.grade || 'A'}급 이상 선수 ${current}명 / 목표 ${g.target}명`;
        break;
      }
      case 'homegrown': {
        const ln = lineup(G).filter(Boolean);
        current = ln.filter(p => p.nation === G.leagueId).length;
        ok = ln.length === 3 && current === 3;
        hint = `라인업 현지 국적 ${current}/3명`;
        break;
      }
      case 'import': {
        const ln = lineup(G).filter(Boolean);
        current = ln.filter(p => p.nation !== G.leagueId).length;
        ok = current >= g.target;
        hint = `라인업 외국인 ${current}명 / 목표 ${g.target}명`;
        break;
      }
      default:
        hint = g.label;
    }
    // 페이스 추정: 시즌 중반 이후 목표 대비 처지면 위험
    let risk = 'on'; // on | warn | danger
    if (g.type === 'rank' || g.type === 'playoff' || g.type === 'msi' || g.type === 'worlds') {
      if (rank > g.target + 3 && round >= Math.floor(total * 0.4)) risk = 'danger';
      else if (rank > g.target && round >= Math.floor(total * 0.35)) risk = 'warn';
      else if (ok) risk = 'on';
    } else if (g.type === 'wins') {
      const pace = total ? (wins / Math.max(1, round)) * total : 0;
      if (round >= 6 && pace < g.target * 0.75) risk = 'danger';
      else if (round >= 4 && pace < g.target * 0.9) risk = 'warn';
      else if (ok) risk = 'on';
    } else if (g.type === 'playoff_win') {
      if (G.phase === 'season' && rank > (CONFIG.league.playoffTeams || 8) && round >= Math.floor(total * 0.5)) risk = 'danger';
      else if (G.phase === 'season' && rank > 4 && round >= Math.floor(total * 0.4)) risk = 'warn';
    }
    return { goal: g, rank, wins, current, ok, hint, risk, round, total };
  }

  function checkPressure(G) {
    const prog = goalProgress(G);
    if (!prog || !G.club.ownerGoal) return null;
    const g = G.club.ownerGoal;
    if (g.status !== 'active') return null;
    // 위험/경고일 때만 압박 카운트 증가, 뉴스용 플래그
    if (prog.risk === 'danger') g.pressure = Math.min(5, (g.pressure || 0) + 1);
    else if (prog.risk === 'warn') g.pressure = Math.min(5, (g.pressure || 0) + 0.5);
    else g.pressure = Math.max(0, (g.pressure || 0) - 0.25);
    // 연속 위험이거나 경고 구간에서 간헐 뉴스
    const shouldWarn = prog.risk === 'danger' || (prog.risk === 'warn' && (g.pressure >= 1.5) && Math.random() < 0.45);
    if (!shouldWarn) return null;
    g.warned = true;
    return prog;
  }

  function evaluateGoal(G) {
    const g = G.club && G.club.ownerGoal;
    if (!g || g.status !== 'active') return null;
    const prog = goalProgress(G);
    let success = false;
    if (g.type === 'rank') success = prog && prog.rank > 0 && prog.rank <= g.target;
    else if (g.type === 'wins') {
      const st = G.league && G.league.standings && G.league.standings.player;
      success = !!(st && st.w >= g.target);
    } else if (g.type === 'playoff') success = prog && prog.rank > 0 && prog.rank <= (CONFIG.league.playoffTeams || 8);
    else if (g.type === 'msi') {
      // MSI 시드 = 전반기 종료 시점 상위 intlTeams. 기록 없으면 최종 순위로 대체
      const intlN = CONFIG.league.intlTeams || 4;
      if (G.msi && G.msi.seeds && G.msi.seeds.includes('player')) success = true;
      else success = prog && prog.rank > 0 && prog.rank <= intlN;
    } else if (g.type === 'playoff_win') success = !!(G.playoff && G.playoff.champion === 'player');
    else success = !!(prog && prog.ok);
    g.status = success ? 'success' : 'fail';
    const cfg = C().goals || {};
    let bonus = 0;
    if (success) {
      const o = C().owner, mul = o.leagueMul[League.lgOf(G).diff] || 1;
      bonus = Math.round(o.base * mul * (g.bonusMul || cfg.bonusMul || 0.35) / 10) * 10;
      G.club.funds += bonus; G.club.goalWins = (G.club.goalWins || 0) + 1;
      if (typeof News !== 'undefined' && News.shiftRep) News.shiftRep(G, cfg.successRep || 5, '구단주 목표 달성');
    } else {
      if (typeof News !== 'undefined' && News.shiftRep) News.shiftRep(G, cfg.failRep || -4, '구단주 목표 실패');
    }
    return { goal: g, success, bonus, prog };
  }

  const goalReward = (G, g) => { const o = C().owner, mul = o.leagueMul[League.lgOf(G).diff] || 1; return Math.round(o.base * mul * ((g && g.bonusMul) || (C().goals || {}).bonusMul || 0.35) / 10) * 10; };

  const CHV = {
    trophy: (G, c) => G.trophies.filter(t => t.k === c.k).length,
    leagues: G => new Set(G.trophies.filter(t => t.k === 'league').map(t => t.lg)).size,
    streak: G => G.bestStreak || 0,
    wins: G => (G.totals && G.totals.wins) || 0,
    goals: G => G.club.goalWins || 0,
    rare: G => roster(G).filter(p => Pros.rarity(p)).length,
    funds: G => Math.round(G.club.funds),
    foreign: G => roster(G).filter(p => p.nation && p.nation !== G.leagueId).length,
    seasons: G => G.season || 1
  };
  const chValue = (G, c) => (CHV[c.type] ? CHV[c.type](G, c) : 0);
  function challenges(G) {
    const done = G.club.ch = G.club.ch || {};
    return (CONFIG.challenges || []).map(c => ({ ...c, value: chValue(G, c), done: done[c.id] != null }));
  }
  function checkChallenges(G) {
    if (!G.club) return [];
    const done = G.club.ch = G.club.ch || {}, out = [];
    (CONFIG.challenges || []).forEach(c => {
      if (done[c.id] != null || chValue(G, c) < c.n) return;
      done[c.id] = G.season || 1; G.club.funds += c.reward; out.push(c);
    });
    return out;
  }

  /* ----- 스폰서 / 광고 제안 ----- */
  function ensureSponsor(G) {
    if (!G.club) return;
    if (G.club.sponsorEarned == null) G.club.sponsorEarned = 0;
    if (G.club.sponsorCD == null) G.club.sponsorCD = 0;
    if (!G.club.pendingSponsor) G.club.pendingSponsor = null;
  }
  function sponsorTier(rep) {
    const tiers = (CONFIG.sponsor && CONFIG.sponsor.tierMul) || [];
    let t = tiers[0] || { rep: 55, mul: 1, label: '소형 광고' };
    tiers.forEach(x => { if (rep >= x.rep) t = x; });
    return t;
  }
  function sponsorChance(rep) {
    const rows = (CONFIG.sponsor && CONFIG.sponsor.chance) || [];
    let p = 0;
    rows.forEach(x => { if (rep >= x.rep) p = x.p; });
    return p;
  }
  function trySponsor(G) {
    ensureSponsor(G);
    const S = CONFIG.sponsor; if (!S) return null;
    if (G.club.pendingSponsor) return null;                    // 미응답 제안 있으면 스킵
    if ((G.club.sponsorCD || 0) > 0) { G.club.sponsorCD--; return null; }
    const rep = (G.rep && G.rep.v) || 50;
    if (rep < (S.minRep || 55)) return null;
    if (Math.random() > sponsorChance(rep)) return null;
    const tier = sponsorTier(rep);
    const lgMul = (S.leagueMul && S.leagueMul[League.lgOf(G).diff]) || 1;
    const jitter = 0.85 + Math.random() * 0.3;
    const amount = Math.round((S.base || 400) * tier.mul * lgMul * jitter / 10) * 10;
    const brands = S.brands || ['스폰서'];
    const brand = brands[Math.floor(Math.random() * brands.length)];
    const offer = {
      id: 'sp' + Date.now().toString(36),
      brand, amount, tier: tier.label, rep,
      round: G.league ? G.league.round : 0
    };
    G.club.pendingSponsor = offer;
    if (typeof News !== 'undefined' && News.sponsorOffer) News.sponsorOffer(G, offer, League.when(G));
    return offer;
  }
  function acceptSponsor(G) {
    ensureSponsor(G);
    const o = G.club.pendingSponsor; if (!o) return { ok: false, msg: '대기 중인 스폰서 제안이 없습니다.' };
    G.club.funds += o.amount;
    G.club.sponsorEarned = (G.club.sponsorEarned || 0) + o.amount;
    G.club.sponsorCD = (CONFIG.sponsor && CONFIG.sponsor.cooldownRounds) || 3;
    G.club.pendingSponsor = null;
    if (typeof News !== 'undefined' && News.sponsorDeal) News.sponsorDeal(G, o, true, League.when(G));
    return { ok: true, msg: `${o.brand} ${o.tier} 계약! +${Pros.money(o.amount)}` };
  }
  function declineSponsor(G) {
    ensureSponsor(G);
    const o = G.club.pendingSponsor; if (!o) return { ok: false, msg: '대기 중인 스폰서 제안이 없습니다.' };
    G.club.sponsorCD = Math.max(1, Math.floor(((CONFIG.sponsor && CONFIG.sponsor.cooldownRounds) || 3) / 2));
    G.club.pendingSponsor = null;
    if (typeof News !== 'undefined' && News.sponsorDeal) News.sponsorDeal(G, o, false, League.when(G));
    return { ok: true, msg: `${o.brand} 제안을 거절했습니다.` };
  }

  const done = (r) => { if (r && r.msg) UI.toast(r.msg, r.ok ? 'good' : 'warn'); Game.save(); UI.refresh(); };
  const actions = {
    proSlot(el) { const g = Game.G; setSlot(g, el.dataset.id, +el.dataset.slot); done(); },
    proClear(el) { clearSlot(Game.G, +el.dataset.slot); done(); },
    proAuto() { autoFill(Game.G); done(); },
    proSign(el) { done(Market.signFA(Game.G, el.dataset.id)); },
    proBuy(el) { done(Market.buyListed(Game.G, el.dataset.id)); },
    proRelease(el) {
      const g = Game.G, p = Pros.get(g, el.dataset.id); if (!p) return;
      if (!confirm(`${p.nick} 선수를 방출하면 위약금 ${Pros.money(Market.releaseFee(p))}이 듭니다. 방출할까요?`)) return;
      done(Market.release(g, p.id));
    },
    proRenew(el) { done(Market.renew(Game.G, el.dataset.id)); },
    mkTab(el) { ProUI.mk({ tab: el.dataset.tab }); },
    mkGrade(el) { ProUI.mk({ grade: el.dataset.g }); },
    spAccept() { done(acceptSponsor(Game.G)); },
    spDecline() { done(declineSponsor(Game.G)); }
  };

  return { init, seasonSetup, migrate, challenges, checkChallenges, goalReward, ensureRoster, roster, lineup, ready, brains, moods, payroll, setSlot, autoFill, ownerPay, settle, assignGoal, goalProgress, checkPressure, evaluateGoal, trySponsor, acceptSponsor, declineSponsor, actions };
})();
