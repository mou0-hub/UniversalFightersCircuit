/* market.js — FA 시장 / 이적 시장 / 영입·방출·재계약
   G.market = { fa:[선수id], round } — 이적 시장은 AI 팀 선수 중 listed 표시가 있는 선수입니다. */

const Market = (() => {
  const M = () => CONFIG.pro.market;
  const ensure = G => (G.market = G.market || { fa: [], round: -99 });
  const FAMIX = { C: 0.4, B: 0.35, A: 0.2, S: 0.05 };
  const faGrade = () => { let r = Math.random(), a = 0; for (const g of ['C', 'B', 'A', 'S']) { a += FAMIX[g]; if (r < a) return g; } return 'C'; };
  const signFee = p => Math.round(p.salary * M().signMul / 10) * 10;
  const releaseFee = p => Math.round(p.salary * Math.max(0, p.years - 1) * M().releaseMul / 10) * 10 + Math.round(p.salary * 0.1 / 10) * 10;
  const renewFee = p => Math.round(p.salary * M().renewMul / 10) * 10;
  const listFee = p => Math.round(p.salary * (M().feeMul[0] + Math.random() * (M().feeMul[1] - M().feeMul[0])) / 10) * 10;

  /* 시장 갱신: FA 일부가 다른 곳으로 떠나고 새 선수가 들어오며, AI 팀 선수 몇 명이 이적 명단에 오릅니다 */
  function refresh(G, full) {
    const m = ensure(G), by = Pros.state(G).by;
    m.fa = m.fa.filter(id => { if (!by[id]) return false; if (full || Math.random() < 0.3) { delete by[id]; return false; } return true; });
    while (m.fa.length < M().faSize) { const p = Pros.gen(G, faGrade()); p.years = Pros.rnd(1, 3); m.fa.push(p.id); }
    G.league.teams.forEach(t => (t.pros || []).forEach(id => { if (by[id]) by[id].listed = false; }));
    const cand = []; G.league.teams.forEach(t => { if (!t.isPlayer) (t.pros || []).forEach(id => { if (by[id]) cand.push({ t, id }); }); });
    Pros.shuffle(cand).slice(0, M().listedSize).forEach(({ id }) => { const p = by[id]; p.listed = true; p.fee = listFee(p); });
    m.round = G.league.round;
  }
  const listed = G => { const out = []; G.league.teams.forEach(t => { if (t.isPlayer) return; (t.pros || []).forEach(id => { const p = Pros.get(G, id); if (p && p.listed) out.push({ p, team: t }); }); }); return out; };

  function canAfford(G, cost) { return G.club.funds >= cost; }
  function rosterFull(G) { return G.club.roster.length >= CONFIG.club.maxRoster; }

  function signFA(G, id) {
    const p = Pros.get(G, id), m = ensure(G); if (!p || !m.fa.includes(id)) return { ok: false, msg: '이미 다른 팀과 계약한 선수입니다.' };
    if (rosterFull(G)) return { ok: false, msg: `선수단은 최대 ${CONFIG.club.maxRoster}명입니다.` };
    const fee = signFee(p); if (!canAfford(G, fee)) return { ok: false, msg: `계약금이 부족합니다. (필요 ${Pros.money(fee)})` };
    G.club.funds -= fee; m.fa = m.fa.filter(x => x !== id); p.team = 'player'; G.club.roster.push(id);
    return { ok: true, msg: `${p.nick} 영입 완료 (계약금 ${Pros.money(fee)})` };
  }
  function buyListed(G, id) {
    const p = Pros.get(G, id), t = G.league.teams.find(x => (x.pros || []).includes(id)); if (!p || !t) return { ok: false, msg: '이적 대상이 아닙니다.' };
    if (rosterFull(G)) return { ok: false, msg: `선수단은 최대 ${CONFIG.club.maxRoster}명입니다.` };
    const transfer = p.fee, fee = transfer + signFee(p); if (!canAfford(G, fee)) return { ok: false, msg: `자금이 부족합니다. (이적료+계약금 ${Pros.money(fee)})` };
    G.club.funds -= fee; t.pros = t.pros.filter(x => x !== id);
    const rep = Pros.gen(G, p.grade === 'S' ? 'A' : p.grade === 'A' ? 'B' : 'C'); t.pros.push(rep.id); rep.team = t.id;      // 판 구단은 한 단계 낮은 선수로 대체
    p.listed = false; p.fee = 0; p.team = 'player'; G.club.roster.push(id);
    return { ok: true, msg: `${p.nick} 이적 완료 (이적료 ${Pros.money(transfer)} + 계약금 ${Pros.money(signFee(p))})` };
  }
  function release(G, id) {
    const p = Pros.get(G, id); if (!p || !G.club.roster.includes(id)) return { ok: false, msg: '선수단에 없는 선수입니다.' };
    const fee = releaseFee(p); if (!canAfford(G, fee)) return { ok: false, msg: `위약금이 부족합니다. (필요 ${Pros.money(fee)})` };
    G.club.funds -= fee; G.club.roster = G.club.roster.filter(x => x !== id); G.club.lineup = G.club.lineup.map(x => (x === id ? null : x));
    p.team = null; ensure(G).fa.push(id);
    return { ok: true, msg: `${p.nick} 방출 (위약금 ${Pros.money(fee)})` };
  }
  function renew(G, id) {
    const p = Pros.get(G, id); if (!p || !G.club.roster.includes(id)) return { ok: false, msg: '선수단에 없는 선수입니다.' };
    const fee = renewFee(p); if (!canAfford(G, fee)) return { ok: false, msg: `재계약금이 부족합니다. (필요 ${Pros.money(fee)})` };
    G.club.funds -= fee; p.years = 2; p.salary = Math.round(p.salary * (1 + M().renewRaise) / 10) * 10;
    return { ok: true, msg: `${p.nick} 재계약 (2년, 연봉 ${Pros.money(p.salary)})` };
  }
  return { refresh, listed, signFA, buyListed, release, renew, signFee, releaseFee, renewFee, ensure };
})();
